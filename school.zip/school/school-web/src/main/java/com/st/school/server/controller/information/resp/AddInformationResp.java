package com.st.school.server.controller.information.resp;

import lombok.Data;

/**
 * @author :LW
 * @since :30/12/23 11:04 AM
 */
@Data
public class AddInformationResp {

    private Long id;

    private String fileUrl;
}
