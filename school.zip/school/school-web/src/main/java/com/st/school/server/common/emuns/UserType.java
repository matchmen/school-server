package com.st.school.server.common.emuns;

import lombok.Getter;

import java.util.Objects;

/**
 * @Author :LW
 * Date:11/12/23 8:46 PM
 */
@Getter
public enum UserType {

    TEACHER(0,"教师"),
    ;

    private Integer code;
    private String desc;

    UserType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static UserType valueOfCode(Integer code) {
        if(Objects.isNull(code)) return null;
        UserType[] values = UserType.values();
        for (int i = 0; i < values.length; i++) {
            if (values[i].getCode().equals(code)) {
                return values[i];
            }
        }
        return null;
    }
}
