package com.st.school.server.controller.user.req;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * SendCodeReq
 * Date:19/11/23 3:58 PM
 * @author liqm
 */
@Data
public class SendCodeReq {

    @NotBlank(message = "邮箱不能为空")
    private String email;
}
