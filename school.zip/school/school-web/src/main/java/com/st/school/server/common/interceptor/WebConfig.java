package com.st.school.server.common.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.Arrays;
import java.util.List;

/**
 * @Author :LW
 * Date:13/12/23 8:08 PM
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {
    private List<String> notNeedUrls = Arrays.asList("/login","/user/sendCode","/user/register");

    @Autowired
    private LoginInterceptor loginInterceptor;
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(loginInterceptor).addPathPatterns("/**")
                .excludePathPatterns(notNeedUrls);

    }

//    @Override
//    public void addCorsMappings(CorsRegistry registry) {
//        registry.addMapping("/**") // 匹配的URL路径
//                .allowedOrigins("*") // 允许的跨域请求来源
//                .allowedMethods("*") // 允许的请求方法
//                .allowedHeaders("*","*") // 允许的请求头
//                .allowCredentials(true) ;// 是否允许发送Cookie
//                //.maxAge(3600); // 预检请求的有效期
//    }

}
