package com.st.school.server.controller.user.req;

import com.st.school.server.common.emuns.UserType;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * SendCodeReq
 * Date:19/11/23 3:58 PM
 * @author liqm
 */
@Data
public class RegisterReq {

    @NotBlank(message = "邮箱不能为空")
    private String email;

    @NotBlank(message = "验证码不能为空")
    private String verifyCode;

    @NotBlank(message = "密码不能为空")
    private String password;

    private Integer userType = UserType.TEACHER.getCode();
}
