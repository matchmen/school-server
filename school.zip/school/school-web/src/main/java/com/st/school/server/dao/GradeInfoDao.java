package com.st.school.server.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.st.school.server.entity.GradeInfo;

/**
 * 年级信息表(GradeInfo)表数据库访问层
 *
 * @author makejava
 * @since 2023-12-14 22:44:05
 */
public interface GradeInfoDao extends BaseMapper<GradeInfo> {



}

