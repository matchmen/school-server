package com.st.school.server.common.emuns;

/**
 * @Author :LW
 * Date:11/12/23 9:24 PM
 */
public enum VerifyCodeType {
    REGISTER,

}
