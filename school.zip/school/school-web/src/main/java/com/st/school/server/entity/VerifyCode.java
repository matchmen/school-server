package com.st.school.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;
import java.io.Serializable;

/**
 * (VerifyCode)实体类
 *
 * @author makejava
 * @since 2023-12-11 21:31:32
 */
@Data
public class VerifyCode implements Serializable {
    private static final long serialVersionUID = 241238731349918442L;
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * 验证码
     */
    private String code;
    /**
     * 类型
      */
    private String verifyCodeType;
    /**
     * 账号
     */
    private String accountNo;
    /**
     * 过期时间
     */
    private LocalDateTime expirationTime;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;



}

