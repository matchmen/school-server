//package com.st.school.server.common.util;
//
//import com.baomidou.mybatisplus.annotation.DbType;
//import com.baomidou.mybatisplus.generator.AutoGenerator;
//import com.baomidou.mybatisplus.generator.config.*;
//import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
//
//public class MybatisPlusGenerator {
//    private static void run(String parentModule, String dbName, String pkgName, String[] tableNames, String packageName) {
//        //1. 全局配置
//        String projectPath = System.getProperty("user.dir");
//        System.out.println("projectPath: " + projectPath);
//
//        String moduleName = parentModule + "/" + "biz";
//
//        GlobalConfig globalConfig = new GlobalConfig()
//                .setOutputDir(projectPath + "/" + moduleName + "/src/main/java")
//                .setServiceImplName("%sSupportImpl")
//                .setAuthor("tk")
//                .setOpen(false);
//
//        //2. 数据源配置
//        DataSourceConfig dataSourceConfig = new DataSourceConfig()
//                .setDbType(DbType.MYSQL)  // 设置数据库类型
//                .setDriverName("com.mysql.cj.jdbc.Driver")
//                .setUrl("jdbc:mysql://10.254.253.11:3306/" + dbName + "?useUnicode=true&useSSL=false&characterEncoding=utf8")
//                .setUsername("hone")
//                .setPassword("^7Tgit3N7OZ6a^E1");
//
//        if (packageName == null || packageName.isEmpty()) {
//            packageName = "";
//        } else if (!packageName.endsWith(".")) {
//            packageName = packageName + ".";
//        }
//
//        //3. 包名策略配置
//        PackageConfig pkConfig = new PackageConfig()
//                .setEntity(packageName + "entity")
//                .setMapper(packageName + "mapper")
//                .setServiceImpl(packageName + "dao")
//                .setParent(pkgName);
//
//        //4. 策略配置
//        StrategyConfig stConfig = new StrategyConfig()
//                .setNaming(NamingStrategy.underline_to_camel) // 数据库表映射到实体的命名策略
//                .setColumnNaming(NamingStrategy.underline_to_camel)
//                .setEntityLombokModel(true)
//                .setInclude(tableNames)
//                .setTablePrefix("ds")
//                .setControllerMappingHyphenStyle(true);
//
//        //5. 整合配置
//        AutoGenerator mpg = new AutoGenerator()
//                .setGlobalConfig(globalConfig)
//                .setDataSource(dataSourceConfig)
//                .setStrategy(stConfig)
//                .setTemplate(new TemplateConfig().setController(null))
//                .setTemplateEngine(new VelocityTemplateEngine())
//                .setPackageInfo(pkConfig);
//        mpg.execute();
//    }
//
//    public static void main(String[] args) {
//        //模块名称
//        String parentModule = "biz";
//        //数据库名称
//        String dbName = "foundation";
//        //包名
//        String pkgName = "io.huione.foundation";
//        // 子包名(按模块分包)
//        String packageName = "biz";
//        //表
//        String[] tablesName = { "thunes_withdraw_order"};
//        run(parentModule, dbName, pkgName, tablesName, packageName);
//    }
//}
