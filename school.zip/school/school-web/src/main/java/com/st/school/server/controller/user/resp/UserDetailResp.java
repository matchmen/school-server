package com.st.school.server.controller.user.resp;

import lombok.Data;

/**
 * @Author :LW
 * Date:13/12/23 9:16 AM
 */
@Data
public class UserDetailResp {
    private String email;
}
