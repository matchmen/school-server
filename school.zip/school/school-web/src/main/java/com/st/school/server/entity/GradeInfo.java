package com.st.school.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 年级信息表(GradeInfo)实体类
 *
 * @author makejava
 * @since 2023-12-14 22:44:05
 */
@Data
public class GradeInfo implements Serializable {
    private static final long serialVersionUID = -25396756728789257L;
    /**
     * ID
     */
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 年级名称
     */
    private String gradeName;
    /**
     * 状态
     */
    private Integer gradeStatus;
    
    private LocalDateTime createTime;

}

