package com.st.school.server.common.user;

import com.st.school.server.common.emuns.UserType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author :LW
 * Date:12/12/23 10:26 PM
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserContextInfo {

    private Long userId;

    private String username;

    private UserType userType;
}
