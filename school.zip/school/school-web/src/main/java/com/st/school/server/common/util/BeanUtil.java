package com.st.school.server.common.util;

import com.st.school.server.common.emuns.SchoolError;
import com.st.school.server.common.exception.BizAssert;
import com.st.school.server.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import java.util.Objects;
import java.util.function.BiConsumer;

/**
 * @author :LW
 * @since :1/1/24 4:06 PM
 */
@Slf4j
public class BeanUtil {

    public static <S, T> T copy(S source, Class<T> target, BiConsumer<S,T> consumer) {
        BizAssert.isTure(Objects.nonNull(source) && Objects.nonNull(target), SchoolError.SYSTEM_ERROR);
        try {
            T t = target.newInstance();
            BeanUtils.copyProperties(source, t);
            if (Objects.nonNull(consumer)) {
                consumer.accept(source, t);
            }
            return t;
        } catch (Exception e) {
            log.error("Bean Copy Exception", e);
            throw new BizException(SchoolError.SYSTEM_ERROR.getCode(), SchoolError.SYSTEM_ERROR.getDesc());
        }
    }

    public static <S, T> T copy(S source, Class<T> target) {
        BizAssert.isTure(Objects.nonNull(source) && Objects.nonNull(target), SchoolError.SYSTEM_ERROR);
        try {
            T t = target.newInstance();
            BeanUtils.copyProperties(source, t);
            return t;
        } catch (Exception e) {
            log.error("Bean Copy Exception", e);
            throw new BizException(SchoolError.SYSTEM_ERROR.getCode(), SchoolError.SYSTEM_ERROR.getDesc());
        }
    }

}
