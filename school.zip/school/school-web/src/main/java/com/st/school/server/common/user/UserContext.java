package com.st.school.server.common.user;

import com.st.school.server.common.emuns.SchoolError;
import com.st.school.server.common.emuns.UserType;
import com.st.school.server.common.exception.BizAssert;

/**
 * @Author :LW
 * Date:12/12/23 10:25 PM
 */
public class UserContext {

    private static ThreadLocal<UserContextInfo> userContext = new ThreadLocal<>();

    public static void setUserContext(UserContextInfo userContextInfo) {
        userContext.set(userContextInfo);
    }

    public static void removeUserContext() {
        userContext.remove();
    }

    public static Long getUserId() {
        UserContextInfo contextInfo = userContext.get();
        BizAssert.notNull(contextInfo, SchoolError.USER_NOT_LOGIN);
        return contextInfo.getUserId();
    }

    public static String getUsername() {
        UserContextInfo contextInfo = userContext.get();
        BizAssert.notNull(contextInfo, SchoolError.USER_NOT_LOGIN);
        return contextInfo.getUsername();
    }

    public static UserType getUserType() {
        UserContextInfo contextInfo = userContext.get();
        BizAssert.notNull(contextInfo, SchoolError.USER_NOT_LOGIN);
        return contextInfo.getUserType();
    }

}
