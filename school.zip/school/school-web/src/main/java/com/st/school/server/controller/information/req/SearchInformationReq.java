package com.st.school.server.controller.information.req;

import com.st.school.server.controller.req.PageReq;
import lombok.Data;

/**
 * @Author :LW
 * Date:14/12/23 11:28 PM
 */
@Data
public class SearchInformationReq extends PageReq {
    private String informationName;
    private Integer subjectId;
    private Integer gradeId;
    private String volume;
}
