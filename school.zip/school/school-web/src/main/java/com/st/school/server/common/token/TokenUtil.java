package com.st.school.server.common.token;
import com.alibaba.fastjson.JSON;
import com.st.school.server.common.util.Base64Util;

/**
 * @Author :LW
 * Date:12/12/23 9:23 PM
 */
public class TokenUtil {

    public static String generateToken(Token tokenInfo) {
        String tokenJson = JSON.toJSONString(tokenInfo);
        return Base64Util.base64Encrypt(tokenJson);
    }

    public static Token resolveToken(String token) {
        String tokenJson = Base64Util.base64Decrypt(token);
        return JSON.parseObject(tokenJson, Token.class);
    }


}
