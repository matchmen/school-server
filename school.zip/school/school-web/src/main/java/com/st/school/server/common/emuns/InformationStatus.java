package com.st.school.server.common.emuns;

import lombok.Getter;

/**
 * @Author :LW
 * Date:15/12/23 12:03 AM
 */
@Getter
public enum InformationStatus {

    DRAFT("草稿"),
    RELEASED("已发布"),

    ;
    private String desc;

    InformationStatus(String desc) {
        this.desc = desc;
    }

}
