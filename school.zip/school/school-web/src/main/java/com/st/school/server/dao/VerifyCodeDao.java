package com.st.school.server.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.st.school.server.entity.VerifyCode;

/**
 * (VerifyCode)表数据库访问层
 *
 * @author makejava
 * @since 2023-12-11 21:31:32
 */
public interface VerifyCodeDao extends BaseMapper<VerifyCode> {



}

