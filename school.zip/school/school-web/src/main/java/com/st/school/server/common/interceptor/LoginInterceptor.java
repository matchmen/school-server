package com.st.school.server.common.interceptor;

import com.st.school.server.common.SchoolConst;
import com.st.school.server.common.exception.BizAssert;
import com.st.school.server.common.thread.CommonTaskExecutor;
import com.st.school.server.common.token.Token;
import com.st.school.server.common.token.TokenUtil;
import com.st.school.server.common.user.UserContext;
import com.st.school.server.common.user.UserContextInfo;
import com.st.school.server.entity.TokenInfo;
import com.st.school.server.service.TokenInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * @Author :LW
 * Date:12/12/23 10:02 PM
 */
@Component
public class LoginInterceptor implements HandlerInterceptor {

    @Autowired
    private TokenInfoService tokenInfoService;

    private List<String> notNeedUrls = Arrays.asList("/login","/user/sendCode","/user/register");

    @Override
    public boolean preHandle(@Nullable HttpServletRequest httpServletRequest, @Nullable HttpServletResponse httpServletResponse, @Nullable Object o) {
        String tokenStr = httpServletRequest.getHeader(SchoolConst.AUTHORIZATION);
        String rul = httpServletRequest.getRequestURL().toString();
        if (!StringUtils.hasText(tokenStr)) {
            httpServletResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
            return false;
        }

        Token token = TokenUtil.resolveToken(tokenStr);
        TokenInfo tokenInfo = tokenInfoService.getToken(token.getUserId());
        if (Objects.isNull(tokenInfo) || tokenInfo.getExpireTime().compareTo(LocalDateTime.now()) <= 0) {
            httpServletResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
            return false;
        }

        UserContext.setUserContext(UserContextInfo.builder()
                .userId(token.getUserId())
                .username(token.getUsername())
                .userType(token.getUserType())
                .build());

        CommonTaskExecutor.submit(() -> tokenInfoService.updateTokenExpireTime(tokenInfo.getId()));

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        UserContext.removeUserContext();
    }



}
