package com.st.school.server.controller.common.resp;

import lombok.Data;

/**
 * @Author :LW
 * Date:14/12/23 10:47 PM
 */
@Data
public class DropdownResp<T> {
    private T key;
    private String desc;
}
