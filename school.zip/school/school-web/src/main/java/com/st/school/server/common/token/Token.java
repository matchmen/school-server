package com.st.school.server.common.token;

import com.st.school.server.common.emuns.UserType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @Author :LW
 * Date:12/12/23 9:25 PM
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Token {

    private Long userId;

    private String username;

    private UserType userType;

    private LocalDateTime expireTime;
}
