package com.st.school.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;
import java.io.Serializable;

/**
 * 用户表(User)实体类
 *
 * @author makejava
 * @since 2023-12-10 17:12:37
 */
@Data
public class User implements Serializable {
    private static final long serialVersionUID = 997044819014132066L;
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * 用户名
     */
    private String username;
    /**
     * 登陆密码
     */
    private String password;
    /**
     * 用户类型,0:教师，1:学生
     */
    private Integer userType;
    /**
     * 状态
     */
    private Integer ban;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 修改时间
     */
    private LocalDateTime updateTime;

}

