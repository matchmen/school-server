package com.st.school.server.common.emuns;

import lombok.Getter;

/**
 * @Author :LW
 * Date:14/12/23 10:52 PM
 */
@Getter
public enum YesOrNo {

    YES(0),
    NO(1),

    ;
    private Integer code;

    YesOrNo(Integer code) {
        this.code = code;
    }
}
