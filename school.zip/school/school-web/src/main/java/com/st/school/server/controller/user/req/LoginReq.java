package com.st.school.server.controller.user.req;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * Date:19/11/23 5:53 PM
 * @author liqm
 */
@Data
public class LoginReq {
    @NotBlank(message = "账户不能为空")
    private String username;
    @NotBlank(message = "密码不能为空")
    private String password;
}
