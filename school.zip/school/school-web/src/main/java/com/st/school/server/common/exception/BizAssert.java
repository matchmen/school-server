package com.st.school.server.common.exception;

import com.st.school.server.common.emuns.SchoolError;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Objects;

/**
 * @Author :LW
 * Date:11/12/23 9:09 PM
 */
public class BizAssert {
    public BizAssert() {
    }

    public static void isNull(Object obj, SchoolError error) {
        if (Objects.isNull(obj)) {
            return;
        }
        throw BizException.bizException(error);
    }

    public static void notNull(Object obj, SchoolError error) {
        if (Objects.nonNull(obj)) {
            return;
        }
        throw BizException.bizException(error);
    }

    public static void isTure(Boolean flg, SchoolError error) {
        if (Objects.nonNull(flg) && Boolean.TRUE.equals(flg)) {
            return;
        }
        throw BizException.bizException(error);
    }


}
