package com.st.school.server.controller.information.resp;

import com.st.school.server.common.util.DateUtil;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * @author :LW
 * @since :30/12/23 6:12 PM
 */
@Data
public class InformationDetailResp {

    private Long id;
    /**
     * 信息名称
     */
    private String informationName;
    /**
     * 删除标记
     */
    private Long deleteFlg;
    /**
     * 信息状态
     */
    private String informationStatus;

    private Integer subjectId;

    private String volume;
    /**
     * 年级ID
     */
    private Integer gradeId;

    private String docType;

    private String addMethod;

    private String content;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 修改时间
     */
    private String updateTime;
}
