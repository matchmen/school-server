package com.st.school.server.service.logic;

import com.st.school.server.common.emuns.UserType;
import com.st.school.server.common.emuns.VerifyCodeType;
import com.st.school.server.common.util.PasswordUtil;
import com.st.school.server.controller.user.req.RegisterReq;
import com.st.school.server.service.UserService;
import com.st.school.server.service.VerifyCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Author :LW
 * Date:11/12/23 9:54 PM
 */
@Component
public class RegisterService {

    @Autowired
    private UserService userService;
    @Autowired
    private VerifyCodeService verifyCodeService;

    public void register(RegisterReq req) {
        PasswordUtil.ruleVerify(req.getPassword());
        verifyCodeService.verifyCode(req.getVerifyCode(), req.getEmail(), VerifyCodeType.REGISTER);
        PasswordUtil.ruleVerify(req.getPassword());
        userService.addUser(req.getEmail(), req.getPassword(), UserType.valueOfCode(req.getUserType()));
    }

}
