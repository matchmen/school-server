package com.st.school.server.common.emuns;

/**
 * @author :LW
 * @since :30/12/23 10:59 AM
 */
public enum InformationAddMethod {

    UPLOAD_DOC("上传文件"),
    NEW_DOC("新建文件")
    ;

    private String desc;

    InformationAddMethod(String desc) {
        this.desc = desc;
    }
}
