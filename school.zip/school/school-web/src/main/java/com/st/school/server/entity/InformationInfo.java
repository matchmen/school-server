package com.st.school.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;
import java.io.Serializable;

/**
 * (InformationInfo)实体类
 *
 * @author makejava
 * @since 2023-12-14 23:48:23
 */
@Data
public class InformationInfo implements Serializable {
    private static final long serialVersionUID = -93354798858997740L;
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * 信息名称
     */
    private String informationName;
    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 删除标记
     */
    private Long deleteFlg;
    /**
     * 信息状态
     */
    private String informationStatus;
    
    private Integer subjectId;

    private String volume;
    /**
     * 年级ID
     */
    private Integer gradeId;

    private String docType;

    private String addMethod;

    private String content;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 修改时间
     */
    private LocalDateTime updateTime;



}

