package com.st.school.server.controller.information.resp;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author :LW
 * @since :30/12/23 11:16 AM
 */
@Data
public class UpdateContentReq {
    private String content;
    @NotNull(message = "资料ID不能为空")
    private Long id;
}
