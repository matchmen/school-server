package com.st.school.server.controller.req;

import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * @Author :LW
 * Date:14/12/23 11:30 PM
 */
@Data
public class PageReq {

    @NotNull(message = "currencyPage required")
    @Min(message = "currencyPage min is 1", value = 1)
    private Integer currencyPage;

    @NotNull(message = "pageSize required")
    @Max(message = "currencyPage min is 1", value = 100)
    private Integer pageSize;
}
