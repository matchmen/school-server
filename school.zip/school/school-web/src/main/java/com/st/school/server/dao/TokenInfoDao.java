package com.st.school.server.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.st.school.server.entity.TokenInfo;
import org.apache.ibatis.annotations.Param;

/**
 * (TokenInfo)表数据库访问层
 *
 * @author makejava
 * @since 2023-12-12 21:49:10
 */
public interface TokenInfoDao extends BaseMapper<TokenInfo> {

    TokenInfo selectTheLastTokenByUserId(@Param("userId") Long userId);

}

