package com.st.school.server.common.util;

/**
 * @Author :LW
 * Date:11/12/23 10:00 PM
 */
public class PasswordUtil {

    public static void ruleVerify(String password) {

    }

    public static String passwordMD5(String password) {

        return MD5Util.strMD5(password);
    }


}
