package com.st.school.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 科目信息表(SubjectInfo)实体类
 *
 * @author makejava
 * @since 2023-12-14 22:44:05
 */
@Data
public class SubjectInfo implements Serializable {
    private static final long serialVersionUID = -25396756728789257L;
    /**
     * ID
     */
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 科目名称
     */
    private String subjectName;
    /**
     * 状态
     */
    private Integer subjectStatus;
    
    private LocalDateTime createTime;

}

