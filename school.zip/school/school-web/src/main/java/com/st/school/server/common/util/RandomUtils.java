package com.st.school.server.common.util;

import java.security.SecureRandom;

public abstract class RandomUtils {
    /**
     * 生成6位的数字验证码
     */
    public static String generateCode() {
        SecureRandom secureRandom = new SecureRandom();
        int code = secureRandom.nextInt(900000) + 100000;
        return String.valueOf(code);
    }
}
