package com.st.school.server.common;

import lombok.Data;

/**
 * Result
 * Date:19/11/23 3:52 PM
 * @author liqm
 */
@Data
public class Result<T> {

    private static final String SUCCESS_CODE = "000000";
    private static final String FAIL_CODE = "-1";

    private String code;

    private String message;

    private T data;

    public static Result success() {
        Result result = new Result();
        result.setCode(Result.SUCCESS_CODE);
        return result;
    }

    public static Result success(Object data) {
        Result result = new Result();
        result.setCode(Result.SUCCESS_CODE);
        result.setData(data);
        return result;
    }

    public static Result fail(String message) {
        Result result = new Result();
        result.setCode(Result.FAIL_CODE);
        result.setMessage(message);
        return result;
    }

    public static Result fail(String code, String message) {
        Result result = new Result();
        result.setCode(code);
        result.setMessage(message);
        return result;
    }
}
