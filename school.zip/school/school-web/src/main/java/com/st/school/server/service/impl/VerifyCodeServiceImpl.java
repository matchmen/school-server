package com.st.school.server.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.st.school.server.common.util.MD5Util;
import com.st.school.server.common.emuns.SchoolError;
import com.st.school.server.common.emuns.VerifyCodeType;
import com.st.school.server.common.exception.BizAssert;
import com.st.school.server.common.util.RandomUtils;
import com.st.school.server.dao.VerifyCodeDao;
import com.st.school.server.entity.VerifyCode;
import com.st.school.server.service.VerifyCodeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * @Author :LW
 * Date:11/12/23 9:34 PM
 */
@Slf4j
@Service
public class VerifyCodeServiceImpl extends ServiceImpl<VerifyCodeDao, VerifyCode> implements VerifyCodeService {
    @Override
    public Boolean generateCode(String accountNo, VerifyCodeType codeType) {

        VerifyCode verifyCode = new VerifyCode();
        String code = RandomUtils.generateCode();
        verifyCode.setCode(MD5Util.strMD5(code));
        verifyCode.setVerifyCodeType(codeType.name());
        verifyCode.setAccountNo(accountNo);
        verifyCode.setExpirationTime(LocalDateTime.now().plusMonths(10));
        verifyCode.setCreateTime(LocalDateTime.now());

        boolean save = save(verifyCode);
        BizAssert.isTure(save, SchoolError.SYSTEM_ERROR);
        log.info("生产验证码accountNo:{}，Code:{}", accountNo, code);
        //TODO Send Code
        return true;
    }

    @Override
    public void verifyCode(String code, String accountNo,VerifyCodeType codeType) {
        VerifyCode verifyCode = findByCodeAndAccountNo(MD5Util.strMD5(code), accountNo, codeType);
        BizAssert.notNull(verifyCode, SchoolError.VERIFY_CODE_ERROR);
        BizAssert.isTure(verifyCode.getExpirationTime().compareTo(LocalDateTime.now()) >= 0, SchoolError.VERIFY_CODE_EXPIRE);
    }

    private VerifyCode findByCodeAndAccountNo(String code, String accountNo,VerifyCodeType codeType) {
        return lambdaQuery().eq(VerifyCode::getCode, code)
                .eq(VerifyCode::getVerifyCodeType,codeType.name())
                .eq(VerifyCode::getAccountNo, accountNo).one();
    }
}
