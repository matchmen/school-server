package com.st.school.server.common.emuns;

import lombok.Getter;

/**
 * @Author :LW
 * Date:11/12/23 9:01 PM
 */
@Getter
public enum SchoolError {
    SYSTEM_ERROR("9999","系统繁忙，请稍后重试。"),
    USER_EXIST("1000","用户名已经存在"),
    USER_NAME_OR_PASSWORD("1001","用户名或密码错误"),
    VERIFY_CODE_ERROR("1002","验证码错误"),
    VERIFY_CODE_EXPIRE("1003","验证码已经过期，请重新获取"),
    USER_NOT_EXIST("1004","用户不存在"),
    OLD_PASSWORD_ERROR("1005","原密码错误"),


    INFORMATION_NOT_EXIST("2001","资料不存在"),

    USER_NOT_LOGIN("999","用户未登录"),
    ;

    private String code;
    private String desc;

    SchoolError(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
