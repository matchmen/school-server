package com.st.school.server.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.st.school.server.entity.User;

/**
 * 用户表(User)表数据库访问层
 *
 * @author makejava
 * @since 2023-12-10 17:13:40
 */
public interface UserDao extends BaseMapper<User> {

}

