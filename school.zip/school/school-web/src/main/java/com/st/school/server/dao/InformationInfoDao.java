package com.st.school.server.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.st.school.server.entity.InformationInfo;

/**
 * (InformationInfo)表数据库访问层
 *
 * @author makejava
 * @since 2023-12-14 23:48:23
 */
public interface InformationInfoDao extends BaseMapper<InformationInfo> {


}

