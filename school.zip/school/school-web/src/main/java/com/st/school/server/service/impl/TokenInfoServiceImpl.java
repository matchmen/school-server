package com.st.school.server.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.st.school.server.common.exception.BizAssert;
import com.st.school.server.dao.TokenInfoDao;
import com.st.school.server.entity.TokenInfo;
import com.st.school.server.service.TokenInfoService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * (TokenInfo)表服务实现类
 *
 * @author makejava
 * @since 2023-12-12 21:49:10
 */
@Service
public class TokenInfoServiceImpl extends ServiceImpl<TokenInfoDao, TokenInfo> implements TokenInfoService {

    @Override
    public void saveToken(Long userId, String token) {

        TokenInfo tokenInfo = new TokenInfo();
        tokenInfo.setToken(token);
        tokenInfo.setUserId(userId);
        tokenInfo.setCreateTime(LocalDateTime.now());
        tokenInfo.setExpireTime(LocalDateTime.now().plusMinutes(30));

        save(tokenInfo);
    }

    @Override
    public TokenInfo getToken(Long userId) {
        return getBaseMapper().selectTheLastTokenByUserId(userId);
    }

    @Override
    public void updateTokenExpireTime(Long tokenId) {
        lambdaUpdate().eq(TokenInfo::getId, tokenId)
                .set(TokenInfo::getExpireTime, LocalDateTime.now().plusMinutes(30))
                .update();
    }


}
