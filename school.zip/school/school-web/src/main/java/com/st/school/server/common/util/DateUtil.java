package com.st.school.server.common.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * @Author :LW
 * Date:15/12/23 12:10 AM
 */
public class DateUtil {

    private static String DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss";

    public static String convertStr(LocalDateTime dateTime) {
        if(Objects.isNull(dateTime)) return "";
        LocalDateTime localDateTime = LocalDateTime.now();
        // 定义日期时间格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DEFAULT_PATTERN);
        // 将 LocalDateTime 对象转换为字符串
        return localDateTime.format(formatter);
    }
}
