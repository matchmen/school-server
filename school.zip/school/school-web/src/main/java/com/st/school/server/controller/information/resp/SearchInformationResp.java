package com.st.school.server.controller.information.resp;

import lombok.Data;

/**
 * @Author :LW
 * Date:14/12/23 11:55 PM
 */
@Data
public class SearchInformationResp {

    private Long id;
    /**
     * 信息名称
     */
    private String informationName;

    private String subjectName;
    private String volume;
    /**
     * 年级
     */
    private String grade;

    private String createTime;

    private String status;

    private String statusDesc;
}
