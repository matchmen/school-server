package com.st.school.server.common.thread;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @Author :LW
 * Date:12/12/23 10:18 PM
 */
public class CommonTaskExecutor {

    private static ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
            4,
            4,
            1*60*1000,
            TimeUnit.SECONDS,
            new LinkedBlockingQueue<Runnable>(2000));

    public static void submit(Runnable runnable) {
        threadPoolExecutor.submit(runnable);
    }


}
