package com.st.school.server.controller.user.req;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @Author :LW
 * Date:14/12/23 9:57 PM
 */
@Data
public class ResetPasswordReq {

    @NotBlank(message = "原密码不能为空")
    private String oldPassword;
    @NotBlank(message = "新密码不能为空")
    private String newPassword;
}
