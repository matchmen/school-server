package com.st.school.server.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.st.school.server.entity.TokenInfo;

/**
 * (TokenInfo)表服务接口
 *
 * @author makejava
 * @since 2023-12-12 21:49:10
 */
public interface TokenInfoService extends IService<TokenInfo> {

    void saveToken(Long userId, String token);

    TokenInfo getToken(Long userId);

    void updateTokenExpireTime(Long tokenId);

}
