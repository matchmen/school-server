package com.st.school.server.service.logic;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.st.school.server.common.emuns.YesOrNo;
import com.st.school.server.dao.GradeInfoDao;
import com.st.school.server.dao.SubjectInfoDao;
import com.st.school.server.entity.GradeInfo;
import com.st.school.server.entity.SubjectInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author :LW
 * Date:14/12/23 10:45 PM
 */
@Service
public class CommonService {
    @Autowired
    private GradeInfoDao gradeInfoDao;
    @Autowired
    private SubjectInfoDao subjectInfoDao;

    public List<GradeInfo> listGrade(){
        LambdaQueryWrapper<GradeInfo> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(GradeInfo::getGradeStatus, YesOrNo.YES);
        return gradeInfoDao.selectList(wrapper);
    }

    public List<SubjectInfo> listSubject(){
        LambdaQueryWrapper<SubjectInfo> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(SubjectInfo::getSubjectStatus, YesOrNo.YES);
        return subjectInfoDao.selectList(wrapper);
    }

    public Map<Integer, String> mapGrade() {
        List<GradeInfo> gradeInfos = listGrade();
        if(CollectionUtils.isEmpty(gradeInfos)) return new HashMap<>();
        return gradeInfos.stream().collect(Collectors.toMap(GradeInfo::getId, GradeInfo::getGradeName));
    }

    public Map<Integer, String> mapSubject() {
        List<SubjectInfo> subjectInfos = listSubject();
        if(CollectionUtils.isEmpty(subjectInfos)) return new HashMap<>();
        return subjectInfos.stream().collect(Collectors.toMap(SubjectInfo::getId, SubjectInfo::getSubjectName));
    }

}
