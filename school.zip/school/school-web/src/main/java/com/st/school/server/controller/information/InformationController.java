package com.st.school.server.controller.information;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.st.school.server.common.Result;
import com.st.school.server.common.emuns.InformationStatus;
import com.st.school.server.common.emuns.SchoolError;
import com.st.school.server.common.emuns.Volume;
import com.st.school.server.common.exception.BizAssert;
import com.st.school.server.common.util.BeanUtil;
import com.st.school.server.common.util.DateUtil;
import com.st.school.server.controller.information.req.AddInformationReq;
import com.st.school.server.controller.information.req.DetailReq;
import com.st.school.server.controller.information.req.SearchInformationReq;
import com.st.school.server.controller.information.resp.AddInformationResp;
import com.st.school.server.controller.information.resp.InformationDetailResp;
import com.st.school.server.controller.information.resp.SearchInformationResp;
import com.st.school.server.controller.information.resp.UpdateContentReq;
import com.st.school.server.controller.resp.PageResp;
import com.st.school.server.entity.GradeInfo;
import com.st.school.server.entity.InformationInfo;
import com.st.school.server.entity.SubjectInfo;
import com.st.school.server.service.InformationInfoService;
import com.st.school.server.service.logic.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @Author :LW
 * Date:14/12/23 11:27 PM
 */
@RestController
@RequestMapping("information")
public class InformationController {

    @Autowired
    private InformationInfoService informationInfoService;
    @Autowired
    private CommonService commonService;

    @PostMapping("search")
    public Result search(@RequestBody @Valid  SearchInformationReq req) {

        IPage<InformationInfo> search = informationInfoService.search(req);
        if (CollectionUtils.isEmpty(search.getRecords())) {
            return Result.success(Collections.EMPTY_LIST);
        }
        Map<Integer, String> mapGrade = commonService.mapGrade();
        Map<Integer, String> mapSubject = commonService.mapSubject();
        PageResp<SearchInformationResp> pageResp = PageResp.buildPageResp(search, SearchInformationResp.class, item -> {
            SearchInformationResp resp = new SearchInformationResp();
            resp.setId(item.getId());
            resp.setInformationName(item.getInformationName());
            resp.setGrade(mapGrade.get(item.getGradeId()) + "(" + Volume.valueOf(item.getVolume()).getDesc() + ")");
            resp.setSubjectName(mapSubject.get(item.getSubjectId()));
            resp.setVolume(Volume.valueOf(item.getVolume()).name());
            resp.setStatus(item.getInformationStatus());
            resp.setStatusDesc(InformationStatus.valueOf(item.getInformationStatus()).getDesc());
            resp.setCreateTime(DateUtil.convertStr(item.getCreateTime()));
            return resp;
        });

        return Result.success(pageResp);
    }

    @PostMapping("add")
    public Result<AddInformationResp> add(@RequestBody @Valid AddInformationReq addInformationReq) {
        return Result.success(informationInfoService.add(addInformationReq));
    }

    @PostMapping("updateContent")
    public Result<UpdateContentResp> updateContent(@RequestBody @Valid UpdateContentReq req) {
        return Result.success(informationInfoService.updateContent(req));
    }

    @PostMapping("detail")
    public Result<InformationDetailResp> detail(@RequestBody DetailReq req) {
        InformationInfo informationInfo = informationInfoService.getById(req.getId());
        BizAssert.notNull(informationInfo, SchoolError.INFORMATION_NOT_EXIST);
        InformationDetailResp detailResp = BeanUtil.copy(informationInfo, InformationDetailResp.class, (s, t) -> {
            t.setCreateTime(DateUtil.convertStr(s.getCreateTime()));
            t.setUpdateTime(DateUtil.convertStr(s.getUpdateTime()));
        });
        return Result.success(detailResp);
    }

}
