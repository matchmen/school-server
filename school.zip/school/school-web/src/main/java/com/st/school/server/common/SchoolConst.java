package com.st.school.server.common;

/**
 * @Author :LW
 * Date:12/12/23 10:08 PM
 */
public interface SchoolConst {

    String AUTHORIZATION = "Authorization";


}
