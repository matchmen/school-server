package com.st.school.server.common.emuns;

import lombok.Getter;

/**
 * @Author :LW
 * Date:14/12/23 10:40 PM
 */
@Getter
public enum Volume {
    VOLUME_ONE("上册"),
    VOLUME_TWO("下册")

    ;
    private String desc;

    Volume(String desc) {
        this.desc = desc;
    }
}
