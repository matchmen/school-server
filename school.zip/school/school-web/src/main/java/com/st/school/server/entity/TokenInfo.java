package com.st.school.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;
import java.io.Serializable;

/**
 * (TokenInfo)实体类
 *
 * @author makejava
 * @since 2023-12-12 21:49:10
 */
@Data
public class TokenInfo implements Serializable {
    private static final long serialVersionUID = 361505114107108072L;
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * 用户ID
     */
    private Long userId;
    /**
     * Token信息
     */
    private String token;
    /**
     * 过期时间
     */
    private LocalDateTime expireTime;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;


}

