package com.st.school.server.controller.user;

import com.st.school.server.common.Result;
import com.st.school.server.common.emuns.UserType;
import com.st.school.server.common.emuns.VerifyCodeType;
import com.st.school.server.common.user.UserContext;
import com.st.school.server.controller.user.req.RegisterReq;
import com.st.school.server.controller.user.req.ResetPasswordReq;
import com.st.school.server.controller.user.req.SendCodeReq;
import com.st.school.server.controller.user.resp.UserDetailResp;
import com.st.school.server.service.UserService;
import com.st.school.server.service.VerifyCodeService;
import com.st.school.server.service.logic.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * RegisterController
 * Date:19/11/23 3:50 PM
 * @author liqm
 */
@RestController
@RequestMapping("user")
public class UserController {

    @Autowired
    private VerifyCodeService verifyCodeService;
    @Autowired
    private RegisterService registerService;
    @Autowired
    private UserService userService;
    @PostMapping("sendCode")
    public Result sendCode(@RequestBody @Valid SendCodeReq req) {
        verifyCodeService.generateCode(req.getEmail(), VerifyCodeType.REGISTER);
        return Result.success();
    }

    @PostMapping("register")
    public Result register(@RequestBody @Valid RegisterReq req) {
        req.setUserType(UserType.TEACHER.getCode());
        registerService.register(req);
        return Result.success();
    }

    @GetMapping("userDetail")
    public Result<UserDetailResp> userDetail() {
        UserDetailResp resp = new UserDetailResp();
        resp.setEmail(UserContext.getUsername());
        return Result.success(resp);
    }

    @PostMapping("resetPassword")
    public Result resetPassword(@RequestBody @Valid ResetPasswordReq req) {
        userService.resetPassword(req);
        return Result.success();
    }

}
