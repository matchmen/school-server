package com.st.school.server.common.exception;

import com.st.school.server.common.emuns.SchoolError;
import lombok.Data;

/**
 * @Author :LW
 * Date:11/12/23 8:59 PM
 */
@Data
public class BizException extends RuntimeException {

    private String code;
    private String message;

    public BizException(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public static BizException bizException(SchoolError error) {
        return new BizException(error.getCode(), error.getDesc());
    }

}
