package com.st.school.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.st.school.server.common.emuns.UserType;
import com.st.school.server.controller.user.req.ResetPasswordReq;
import com.st.school.server.entity.User;

/**
 * 用户表(User)表服务接口
 *
 * @author makejava
 * @since 2023-12-10 17:13:40
 */
public interface UserService extends IService<User> {

    Boolean addUser(String username, String password, UserType userType);

    String login(String username, String password);

    User findByUsername(String username);

    void resetPassword(ResetPasswordReq req);

}

