package com.st.school.server.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.st.school.server.common.emuns.InformationStatus;
import com.st.school.server.common.emuns.SchoolError;
import com.st.school.server.common.exception.BizAssert;
import com.st.school.server.common.user.UserContext;
import com.st.school.server.common.util.DateUtil;
import com.st.school.server.controller.information.UpdateContentResp;
import com.st.school.server.controller.information.req.AddInformationReq;
import com.st.school.server.controller.information.req.SearchInformationReq;
import com.st.school.server.controller.information.resp.AddInformationResp;
import com.st.school.server.controller.information.resp.UpdateContentReq;
import com.st.school.server.dao.InformationInfoDao;
import com.st.school.server.entity.InformationInfo;
import com.st.school.server.service.InformationInfoService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * (InformationInfo)表服务实现类
 *
 * @author makejava
 * @since 2023-12-14 23:48:23
 */
@Service("informationInfoService")
public class InformationInfoServiceImpl extends ServiceImpl<InformationInfoDao,InformationInfo> implements InformationInfoService {

    @Override
    public IPage<InformationInfo> search(SearchInformationReq req) {

        LambdaQueryWrapper<InformationInfo> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(StringUtils.hasText(req.getInformationName()), InformationInfo::getInformationName, req.getInformationName());
        wrapper.eq(Objects.nonNull(req.getGradeId()), InformationInfo::getGradeId, req.getGradeId());
        wrapper.eq(Objects.nonNull(req.getSubjectId()), InformationInfo::getGradeId, req.getSubjectId());
        wrapper.eq(StringUtils.hasText(req.getVolume()), InformationInfo::getVolume, req.getVolume());
        wrapper.orderByDesc(InformationInfo::getCreateTime, InformationInfo::getId);
        return getBaseMapper().selectPage(new Page<>(req.getCurrencyPage(), req.getPageSize()), wrapper);
    }

    @Override
    public AddInformationResp add(AddInformationReq req) {
        InformationInfo info = new InformationInfo();
        info.setInformationStatus(InformationStatus.DRAFT.name());
        info.setInformationName(req.getInformationName());
        info.setVolume(req.getVolume());
        info.setGradeId(req.getGradeId());
        info.setUserId(UserContext.getUserId());
        info.setDeleteFlg(0L);
        info.setCreateTime(LocalDateTime.now());
        info.setUpdateTime(LocalDateTime.now());
        info.setSubjectId(req.getSubjectId());
        info.setAddMethod(req.getAddMethod());
        info.setDocType(req.getDocType());
        boolean save = save(info);
        BizAssert.isTure(save, SchoolError.SYSTEM_ERROR);
        AddInformationResp resp = new AddInformationResp();
        resp.setId(info.getId());
        return resp;
    }

    @Override
    public UpdateContentResp updateContent(UpdateContentReq req) {
        InformationInfo informationInfo = getById(req.getId());
        BizAssert.notNull(informationInfo,SchoolError.INFORMATION_NOT_EXIST);
        boolean update = lambdaUpdate().eq(InformationInfo::getId, req.getId())
                .set(InformationInfo::getContent, req.getContent())
                .set(InformationInfo::getUpdateTime, LocalDateTime.now())
                .update();
        BizAssert.isTure(update, SchoolError.SYSTEM_ERROR);

        UpdateContentResp resp = new UpdateContentResp();
        resp.setUpdateTime(DateUtil.convertStr(LocalDateTime.now()));
        return resp;
    }

    @Override
    public InformationInfo getById(Long id) {
        return getBaseMapper().selectById(id);
    }
}
