package com.st.school.server.controller.resp;

import com.baomidou.mybatisplus.core.metadata.IPage;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/**
 * @Author :LW
 * Date:14/12/23 11:31 PM
 */
@Data
public class PageResp<T> {
    private List<T> rows;
    private Long currencyPage;
    private Long pageSize;
    private Long total;

    public static <I, O> PageResp<O> buildPageResp(IPage<I> page, Class<O> clazz, Function<I, O> function) {
        PageResp<O> result = new PageResp<>();
        result.setCurrencyPage(page.getCurrent());
        result.setPageSize(page.getSize());
        result.setTotal(page.getTotal());
        List<O> list = new ArrayList<>();
        result.setRows(list);
        if (CollectionUtils.isEmpty(page.getRecords())) {
            return result;
        }
        for (int i = 0; i < page.getRecords().size(); i++) {
            list.add(function.apply(page.getRecords().get(i)));
        }
        return result;
    }
}
