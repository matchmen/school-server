package com.st.school.server.controller.user;

import com.st.school.server.common.Result;
import com.st.school.server.controller.user.req.LoginReq;
import com.st.school.server.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * Date:19/11/23 5:52 PM
 * @author liqm
 */
@RestController
@RequestMapping("login")
public class LoginController {

    @Autowired
    private UserService userService;

    @PostMapping
    public Result login(@RequestBody @Valid LoginReq req) {
        return Result.success(userService.login(req.getUsername(), req.getPassword()));
    }

}
