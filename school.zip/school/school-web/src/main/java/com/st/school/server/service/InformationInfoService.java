package com.st.school.server.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.st.school.server.controller.information.UpdateContentResp;
import com.st.school.server.controller.information.req.AddInformationReq;
import com.st.school.server.controller.information.req.SearchInformationReq;
import com.st.school.server.controller.information.resp.AddInformationResp;
import com.st.school.server.controller.information.resp.UpdateContentReq;
import com.st.school.server.entity.InformationInfo;

/**
 * (InformationInfo)表服务接口
 *
 * @author makejava
 * @since 2023-12-14 23:48:23
 */
public interface InformationInfoService extends IService<InformationInfo> {

    IPage<InformationInfo> search(SearchInformationReq req);

    AddInformationResp add(AddInformationReq req);

    UpdateContentResp updateContent(UpdateContentReq req);

    InformationInfo getById(Long id);

}
