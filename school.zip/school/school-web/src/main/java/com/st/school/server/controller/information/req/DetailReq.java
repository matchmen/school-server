package com.st.school.server.controller.information.req;

import lombok.Data;

/**
 * @author :LW
 * @since :30/12/23 6:15 PM
 */
@Data
public class DetailReq {
    private Long id;
}
