package com.st.school.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.st.school.server.common.emuns.VerifyCodeType;
import com.st.school.server.entity.VerifyCode;

/**
 * (VerifyCode)表服务接口
 *
 * @author makejava
 * @since 2023-12-11 21:31:32
 */
public interface VerifyCodeService extends IService<VerifyCode> {

    Boolean generateCode(String accountNo, VerifyCodeType codeType);

    void verifyCode(String code, String accountNo,VerifyCodeType codeType);

}
