package com.st.school.server.controller.common;

import com.st.school.server.common.Result;
import com.st.school.server.common.emuns.DocType;
import com.st.school.server.controller.common.resp.DropdownResp;
import com.st.school.server.entity.GradeInfo;
import com.st.school.server.entity.SubjectInfo;
import com.st.school.server.service.logic.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @Author :LW
 * Date:14/12/23 10:46 PM
 */
@RestController
@RequestMapping("common")
public class CommonController {

    @Autowired
    private CommonService commonService;

    @GetMapping("gradeDropdown")
    public Result<List<DropdownResp<Integer>>> gradeDropdown() {
        List<GradeInfo> gradeInfos = commonService.listGrade();
        if (CollectionUtils.isEmpty(gradeInfos)) {
            return Result.success(Collections.emptyList());
        }
        List<DropdownResp<Integer>> list = new ArrayList<>();
        for (int i = 0; i < gradeInfos.size(); i++) {
            DropdownResp<Integer> dropdownResp = new DropdownResp<>();
            dropdownResp.setKey(gradeInfos.get(i).getId());
            dropdownResp.setDesc(gradeInfos.get(i).getGradeName());
            list.add(dropdownResp);
        }
        return Result.success(list);
    }

    @GetMapping("subjectDropdown")
    public Result<List<DropdownResp<Integer>>> subjectDropdown() {
        List<SubjectInfo> gradeInfos = commonService.listSubject();
        if (CollectionUtils.isEmpty(gradeInfos)) {
            return Result.success(Collections.emptyList());
        }
        List<DropdownResp<Integer>> list = new ArrayList<>();
        for (int i = 0; i < gradeInfos.size(); i++) {
            DropdownResp<Integer> dropdownResp = new DropdownResp<>();
            dropdownResp.setKey(gradeInfos.get(i).getId());
            dropdownResp.setDesc(gradeInfos.get(i).getSubjectName());
            list.add(dropdownResp);
        }
        return Result.success(list);
    }

    @GetMapping("docTypeDropdown")
    public Result<List<DropdownResp<String>>> docTypeDropdown() {
        DocType[] values = DocType.values();
        List<DropdownResp<String>> list = new ArrayList<>();
        for (int i = 0; i < values.length; i++) {
            DropdownResp<String> dropdownResp = new DropdownResp<>();
            dropdownResp.setKey(values[i].name());
            dropdownResp.setDesc(values[i].getDesc());
            list.add(dropdownResp);
        }
        return Result.success(list);
    }
}
