package com.st.school.server.common.advice;

import com.st.school.server.common.Result;
import com.st.school.server.common.emuns.SchoolError;
import com.st.school.server.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import javax.validation.UnexpectedTypeException;
import javax.validation.ValidationException;

/**
 * GlobalResponseAdvice
 * Date:19/11/23 4:24 PM
 * @author liqm
 */
@Slf4j
@ResponseBody
@ControllerAdvice(basePackages = "com.st.school.server.controller")
public class GlobalResponseAdvice {

    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseStatus(HttpStatus.OK)
    public Result handleBizException(MethodArgumentNotValidException exception) {
        return Result.fail(exception.getBindingResult().getAllErrors().get(0).getDefaultMessage());
    }

    @ExceptionHandler(ValidationException.class)
    @ResponseStatus(HttpStatus.OK)
    public Result validationException(ValidationException e) {
        return Result.fail(e.getMessage());
    }

    @ExceptionHandler(BizException.class)
    @ResponseStatus(HttpStatus.OK)
    public Result validationBizException(BizException e) {
        return Result.fail(e.getCode(), e.getMessage());
    }

    /**
     * ServletRequestBindingException 所有缺失参数的异常的基础类
     * @param e
     * @return
     */
    @ExceptionHandler(ServletRequestBindingException.class)
    @ResponseStatus(HttpStatus.OK)
    public Result servletRequestBindingException(ServletRequestBindingException e) {
        return Result.fail("参数缺失");
    }

    /**
     * 分辨不清异常类型时使用，
     */
    @ExceptionHandler(UnexpectedTypeException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result unexpectedTypeException(UnexpectedTypeException e) {
        return Result.fail(e.getMessage());
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result missingServletRequestParameterException(MissingServletRequestParameterException e) {
        return Result.fail("缺少参数" + e.getParameterName());
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result methodArgumentTypeMismatchException(MethodArgumentTypeMismatchException e) {
        log.error("系统异常", e);
        return Result.fail(SchoolError.SYSTEM_ERROR.getCode(), SchoolError.SYSTEM_ERROR.getDesc());
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.OK)
    public Result exception(Exception e) {
        log.error("系统异常", e);
        return Result.fail(SchoolError.SYSTEM_ERROR.getCode(), SchoolError.SYSTEM_ERROR.getDesc());
    }

}
