package com.st.school.server.controller.information;

import lombok.Data;

/**
 * @author :LW
 * @since :1/1/24 4:18 PM
 */
@Data
public class UpdateContentResp {

    private String updateTime;
}
