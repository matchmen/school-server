package com.st.school.server.common.emuns;

import lombok.Getter;

/**
 * @author :LW
 * @since :30/12/23 11:09 AM
 */
public enum DocType {

    WORD("Word"),PPT("换灯片(PPT)"),EXCEL("表格")
    ;
    @Getter
    private String desc;

    DocType(String desc) {
        this.desc = desc;
    }
}
