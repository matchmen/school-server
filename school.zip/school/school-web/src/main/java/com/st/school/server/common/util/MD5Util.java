package com.st.school.server.common.util;

import com.st.school.server.common.emuns.SchoolError;
import com.st.school.server.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @Author :LW
 * Date:11/12/23 8:51 PM
 */
@Slf4j
public class MD5Util {


    public static String strMD5(String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(value.getBytes());
            byte[] byteArray = md5.digest();

            BigInteger bigInt = new BigInteger(1, byteArray);
            // 参数16表示16进制
            String result = bigInt.toString(16);
            // 不足32位高位补零
            while(result.length() < 32) {
                result = "0" + result;
            }
            return result;
        } catch (NoSuchAlgorithmException e) {
            log.error("获取MD5值异常:", e);
            throw BizException.bizException(SchoolError.SYSTEM_ERROR);
        }
    }

}
