package com.st.school.server.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.st.school.server.common.emuns.SchoolError;
import com.st.school.server.common.emuns.UserType;
import com.st.school.server.common.exception.BizAssert;
import com.st.school.server.common.token.Token;
import com.st.school.server.common.token.TokenUtil;
import com.st.school.server.common.user.UserContext;
import com.st.school.server.common.util.PasswordUtil;
import com.st.school.server.controller.user.req.ResetPasswordReq;
import com.st.school.server.dao.UserDao;
import com.st.school.server.entity.User;
import com.st.school.server.service.TokenInfoService;
import com.st.school.server.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;

/**
 * @Author :LW
 * Date:11/12/23 8:44 PM
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserDao, User> implements UserService {

    @Autowired
    private TokenInfoService tokenInfoService;

    @Override
    public Boolean addUser(String username, String password, UserType userType) {

        BizAssert.isNull(findByUsername(username), SchoolError.USER_EXIST);

        User user = new User();
        user.setUserType(userType.getCode());
        user.setBan(0);
        user.setUsername(username);
        user.setPassword(PasswordUtil.passwordMD5(password));
        user.setCreateTime(LocalDateTime.now());
        user.setUpdateTime(LocalDateTime.now());
        return save(user);
    }

    @Override
    public String login(String username, String password) {
        User user = findByUsername(username);
        BizAssert.notNull(user, SchoolError.USER_NAME_OR_PASSWORD);
        BizAssert.isTure(StringUtils.endsWithIgnoreCase(PasswordUtil.passwordMD5(password), user.getPassword()), SchoolError.USER_NAME_OR_PASSWORD);

        Token token = new Token();
        token.setUserId(user.getId());
        token.setUserType(UserType.valueOfCode(user.getUserType()));
        token.setUsername(user.getUsername());
        String tokenStr = TokenUtil.generateToken(token);
        tokenInfoService.saveToken(user.getId(), tokenStr);

        return tokenStr;
    }

    @Override
    public User findByUsername(String username) {
        return lambdaQuery().eq(User::getUsername, username).one();
    }

    @Override
    public void resetPassword(ResetPasswordReq req) {
        User user = lambdaQuery().eq(User::getId, UserContext.getUserId()).one();
        BizAssert.notNull(user, SchoolError.USER_NOT_EXIST);
        PasswordUtil.ruleVerify(req.getNewPassword());
        BizAssert.isTure(StringUtils.endsWithIgnoreCase(user.getPassword(), PasswordUtil.passwordMD5(req.getOldPassword())), SchoolError.OLD_PASSWORD_ERROR);

        lambdaUpdate().eq(User::getId, UserContext.getUserId())
                .set(User::getPassword, PasswordUtil.passwordMD5(req.getNewPassword()))
                .set(User::getUpdateTime, LocalDateTime.now())
                .update();
    }


}
