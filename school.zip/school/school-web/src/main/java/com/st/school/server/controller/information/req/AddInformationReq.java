package com.st.school.server.controller.information.req;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author :LW
 * @since :30/12/23 10:57 AM
 */
@Data
public class AddInformationReq {
    /**
     * 信息名称
     */
    @NotBlank(message = "资料名称不能为空")
    private String informationName;
    @NotNull(message = "请选择科目")
    private Integer subjectId;
    @NotBlank(message = "请选择上/下册")
    private String volume;
    @NotNull(message = "请选择年级")
    private Integer gradeId;
    @NotNull(message = "请选择资料类型")
    private String docType;
    @NotNull(message = "请选择资料类型")
    private String addMethod;
}
