import { createStore } from 'vuex'

export default createStore({
  //全局状态初始值
  state: {
    userContext: (localStorage.getItem("userContext") && JSON.parse(localStorage.getItem("userContext")))||{}
  },
  getters: {

  },
  mutations: {
    setUserContext(state,uInfo){
      state.userContext=uInfo
    }
  },
  actions: {
  },
  modules: {
  }
})
