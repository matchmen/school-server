<template>
  
</template>

<script>
import Quill from 'quill';
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
import Bold from 'quill/formats/bold';
export default {

}
</script>

<style>

</style>