<template>
    <div>
      <QuillEditor :theme="textData.theme" :modules="modules" v-model="textData.content" toolbar="full"></QuillEditor>
    </div>
  </template>
  
  <script>
  import { reactive, toRefs } from 'vue';
  import BlotFormatter from 'quill-blot-formatter'
  import { QuillEditor } from '@vueup/vue-quill';
  import '@vueup/vue-quill/dist/vue-quill.snow.css';
  import '@vueup/vue-quill/dist/vue-quill.bubble.css';

  //参考quill官网:https://vueup.github.io/vue-quill/guide/modules.html
  export default {
    components:{
        QuillEditor
    },

    setup(){
        const data = reactive({
            isShow:false,
            modules: [
                {
                    name: 'blotFormatter',  
                    module: BlotFormatter
                }
            ],
            textData:{
                "content": 'xx',
                "theme": 'snow', 
                "editorOptions": {
                    placeholder: '在此输入内容...', 
                    // modules: {
                    //     toolbar: [
                    //         ['bold', 'italic', 'underline', 'strike'],
                    //         ['blockquote', 'code-block'],
                    //         [{ header: 1 }, { header: 2 }],
                    //         [{ list: 'ordered' }, { list: 'bullet' }],
                    //         [{ script: 'sub' }, { script: 'super' }],
                    //         [{ indent: '-1' }, { indent: '+1' }],
                    //         [{ direction: 'rtl' }],
                    //         [{ size: ['small', false, 'large', 'huge'] }],
                    //         [{ header: [1, 2, 3, 4, 5, 6, false] }],
                    //         [{ color: [] }, { background: [] }],
                    //         [{ font: [] }],
                    //         [{ align: [] }],
                    //         ['clean'],
                    //         ['link', 'image', 'video']
                    //     ]
                    // }
                }
            }
        })
        return{
            ...toRefs(data)
        }
    }

  }
  </script>

  <style>
  </style>