<template>
  <div>
    <el-calendar>
</el-calendar>
  </div>
</template>

<script>
import { reactive, toRefs,ref } from 'vue'
export default {
  setup(){
    const data = reactive({
      date: new Date()
    })
  }
}
</script>

<style>

</style>