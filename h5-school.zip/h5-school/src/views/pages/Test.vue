<template>
    <div>
      <G6Chart />
    </div>
  </template>
  
  <script>
  import G6Chart from './graph/G6Chart.vue';
  
  export default {
    components: {
        G6Chart,
    },
  }
  </script>