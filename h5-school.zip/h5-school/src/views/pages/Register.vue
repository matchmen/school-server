<template>
  
  <div style="margin-top: 5%;width: 100%;">
    
    <h1 style="margin-top: 1%;">注册过程</h1>

    <el-steps :active="active" style="margin-top: 4%;" align-center>
      <el-step title="填写基本信息"></el-step>
      <el-step title="验证"></el-step>
      <el-step title="完成"></el-step>
    </el-steps>
    <div class="step-class" v-show="active==1">
      <el-form 
        ref="sendVodeFormRef" 
        class="register-from"
        :model="registerData">
        <el-form-item 
        prop="email"
          class="register-from-item"
          :rules="[{
                    required:true,
                    message:'请输入邮箱',
                    trigger: 'blur',
                 }]">
          <el-input placeholder="请输入邮箱"  v-model="registerData.email">
          </el-input>
        </el-form-item>
      </el-form>
    </div>
    <div class="step-class"  v-show="active==2">
      <el-form 
        ref="verifyCodeFormRef" 
        class="register-from"
        :model="registerData">
        <el-form-item 
          prop="verifyCode"
          class="register-from-item"
          label="验证码"
          :rules="[{
                      required:true,
                      message:'请输入验证码',
                      trigger: 'blur',
                  }]">
          <el-input placeholder="请输入验证码" v-model="registerData.verifyCode">
          </el-input>
        </el-form-item>
        <el-form-item 
          prop="password"
          label="密码"
          class="register-from-item"
          :rules="[{
                      required:true,
                      message:'请输入密码',
                      trigger: 'blur',
                  }]">
          <el-input placeholder="请输入密码" v-model="registerData.password">
          </el-input>
        </el-form-item>
      </el-form>
    </div>
    <div class="step-class" v-show="active==3">
        <h2>注册成功</h2>
    </div>
    <div class="button-class" >
      <el-button v-show="active ==2" @click="prev">上一步</el-button>
      <el-button v-show="active ==2 || active ==1" @click="next">下一步</el-button>
      <el-button v-show="active ==3" @click="toLogin">返回登陆</el-button>
    </div>

  </div>
  
</template>

<script>
import { reactive, toRefs,ref } from 'vue'
import {sendCodeApi,verifyCodeApi} from "../../util/api/request.js"
import { useRouter } from 'vue-router';
import { trigger } from 'vue';

export default {
    setup(){
      const router = useRouter()
      const sendVodeFormRef = ref(null)
      const verifyCodeFormRef = ref(null)
      
      const data = reactive({
        registerData:{
          email:"",
          verifyCode:"",
          password:""
        },
        active: 1
      })
      const prev=()=>{
        data.active = data.active - 1
      }

      const next=()=>{

        if(data.active == 1){
          sendVodeFormRef.value.validate((valid) => {
            if(valid){
              sendCodeApi(data.registerData).then(res=>{
                    if(res.code == '000000'){
                        data.active = 2
                        return
                    }
                })
            }
          })
          return
        } 
        if(data.active == 2){
          verifyCodeFormRef.value.validate((valid) => {
            if(valid){
              verifyCodeApi(data.registerData).then(res=>{
                    if(res.code == '000000'){
                        data.active = 3
                        return
                    }
                })
            }
          })
          return


        }
      }

      const toLogin =()=>{
        router.push({
            path: "/login"
        })

      }

      return {
        ...toRefs(data),
        prev,
        next,
        sendVodeFormRef,
        verifyCodeFormRef,
        toLogin
      }

    }
    
}
</script>

<style>

  .register-from {
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    
  }

  .register-from-item{
    width: 30%;
  }

  .step-class{
    margin-top: 3%;
  }
  
  .button-class{
    margin-top: 2%;
  }

</style>@/util/api/request