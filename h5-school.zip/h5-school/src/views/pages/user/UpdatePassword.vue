<template>
  <div>
    <el-form  class="resetPasswordDataClazz"
      :model="resetPasswordData" 
      status-icon 
      ref="updatePasswordRef" 
      label-width="100px">
      <el-form-item label="原密码" 
        prop="oldPassword"
        :rules="[{
            required:true,
            message:'请输入原密码',
            trigger: 'blur',
        }]">
        <el-input type="password" v-model="resetPasswordData.oldPassword" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item 
        label="新密码"
        prop="newPassword"
        :rules="[{
              required:true,
              message:'请输入新密码',
              trigger: 'blur',
          }]">
        <el-input type="password" v-model="resetPasswordData.newPassword" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="再次输入新密码" 
        prop="newPassword1"
        :rules="[{
            required:true,
            message:'请输入验证码',
            trigger: 'blur',
        }]">
        <el-input type="password" v-model="resetPasswordData.newPassword1" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="cancel">取消</el-button>
        <el-button type="primary" @click="submitForm">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import { reactive, ref, toRefs } from 'vue'
import { useRouter } from 'vue-router'
import { resetPasswordApi} from "../../../util/api/request.js"
import { ElMessage } from 'element-plus'
export default {
  setup(){
    const updatePasswordRef=ref(null)
    
    const router=useRouter()
    const data=reactive({
      resetPasswordData:{
          "oldPassword":"",
          "newPassword":"",
          "newPassword1":""
      }
    })

    const submitForm=()=>{
      updatePasswordRef.value.validate((valid) => {

        if(data.resetPasswordData.newPassword != data.resetPasswordData.newPassword1){
          ElMessage({
            message:"两次输入密码不一致",
            type: "error",
            duration:2000
          })
          return;
        }

        if(valid){
            resetPasswordApi(data.resetPasswordData).then(res=>{
                  if(res.code == '000000'){
                    localStorage.removeItem("userContext")
                    router.push({
                        path: "/login"
                    })
                  }
              })
            }
          })
    }

    const cancel=()=>{
      router.go(-1)
    }

    return{
        ...toRefs(data),
        submitForm,
        cancel,
        updatePasswordRef
      }
  }
}
</script>

<style>
.resetPasswordDataClazz{
  margin-top: 5%;
  width: 50%;
}


</style>@/util/api/request