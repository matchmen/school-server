<template>
    <div>
        <el-descriptions 
            :colon="true"
            style="margin-top: 5%;">
            <el-descriptions-item label="邮箱地址">gq_lqm@163.com</el-descriptions-item>
        </el-descriptions>
        <el-button>重置密码</el-button>
    </div>
</template>