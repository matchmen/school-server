<template>
    <div>
        <el-descriptions 
            :column="1"
            style="margin-top: 5%;">
            <el-descriptions-item style="width: 100%;" label="邮箱地址">{{ userData.email }}</el-descriptions-item>
            <el-descriptions-item style="margin-top: 10%;"><el-button @click="resetPassword">重置密码</el-button></el-descriptions-item>
        </el-descriptions>
        
    </div>
</template>

<script>
import { useRouter } from 'vue-router'
import {userDetailApi} from "../../../util/api/request.js";
import { reactive, toRefs ,onMounted} from 'vue';
export default {
    setup(){
        const data=reactive({
            userData:{
                email:""
            }
        })
        const router = useRouter()

        onMounted(() => {
            queryUserInfo()
        })

        const queryUserInfo=()=>{
            userDetailApi().then(res=>{
                if(res.code == '000000'){
                    data.userData.email=res.data.email
                }else{
                    console.log("no data")
                }
            })
        }
        const resetPassword=()=>{
            router.push({
                path:"/user/updatePW"
            })
        }
        return{
            ...toRefs(data),
            resetPassword,
            onMounted
        }
    }
}
</script>@/util/api/request