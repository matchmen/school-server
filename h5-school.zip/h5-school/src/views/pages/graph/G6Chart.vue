<template>
    <div ref="container" style="height: 500px;"></div>
</template>


<script>
import { ref, onMounted } from 'vue';
import * as G6 from '@antv/g6';
export default {
    setup() {
        const container = ref(null);

        onMounted(() => {
            const graph = new G6.Graph({
                container: container.value,
                width: 500,
                height: 500,
                fitViewPadding:20 / [ 20, 40, 50, 20 ],
                animate:true,
                modes: {
                default: ['drag-canvas', 'zoom-canvas', 'drag-node', 'click-select', 'brush-select'], // 允许拖拽画布、放缩画布、拖拽节点、点选节点、框选节点
  },
            });

            graph.data({
                // 点集
                nodes: [
                {
                    id: 'node1',
                    x: 100,
                    y: 200,
                },
                {
                    id: 'node2',
                    x: 300,
                    y: 200,
                },
                {
                    id: 'node3',
                    x: 150,
                    y: 300,
                }
                ],
                // 边集
                edges: [
                // 表示一条从 node1 节点连接到 node2 节点的边
                {
                    source: 'node1',
                    target: 'node2',
                },
                {
                    source: 'node2',
                    target: 'node3',
                },
                ],
            });
            graph.render();
        });

        return {
            container,
        };
    },
}
</script>

<style>

</style>