<template>
    <div class="login-form">
        <el-form ref="loginFormRef" 
            :model="loginData"  
            label-width="70px">
            <el-form-item 
                prop="username" 
                label="用户名" 
                :rules="[{
                    required:true,
                    message:'请输入用户名',
                    trigger: 'blur',
                 }]">
                <el-input v-model="loginData.username"/>
            </el-form-item>
            <el-form-item 
                prop="password"
                label="密码" 
                :rules="[{
                    required:true,
                    message:'请输入密码',
                    trigger: 'blur',
                }]"
                >
                <el-input type="password" v-model="loginData.password" />
            </el-form-item>  
            <el-form-item>
                <el-button type="primary" @click="loginHandle">登陆</el-button
                >
                <el-button @click="registerHandle">注册</el-button>
            </el-form-item>
        </el-form>
    </div>
  </template>
  
  
  <script>
import store from '@/store';
import { trigger } from 'vue';
import { reactive, toRefs,ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';
import {loginApi} from "../../util/api/request.js";

    export default {
        name:"login",
        setup(){
            const loginFormRef = ref(null); 
            const store  = useStore()
            const router = useRouter()
            const data = reactive({
                loginData:{
                    username:"",
                    password:""
                }
            })
            
            const loginHandle=()=>{
                loginFormRef.value.validate((valid) => {
                    if(valid){
                        loginApi(data.loginData).then(res=>{
                            if(res.code == '000000'){
                                var userContext = {
                                    username:data.loginData.username,
                                    token:res.data
                                }
                                store.commit("setUserContext",userContext)
                                console.log(res.data)
                                localStorage.setItem("userContext",JSON.stringify(userContext))
                                router.push({
                                    path: "/index"
                                })
                                return
                            }
                        })
                    }else{
                        //console.log("xxxx")
                    }
                })
            }
            const registerHandle=()=>{
                router.push({
                    path: "/register"
                })
            }

            return{
                ...toRefs(data),
                loginFormRef,
                loginHandle,
                registerHandle
                
            }
        }
    }
</script>

  <style>
    
  .login-form{
    display: flex;
    justify-content: center;
    align-items: center;
    height:80vh
  }
    
  </style>  
  @/util/api/request