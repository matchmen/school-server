<template>

<el-page-header class="browse" @back="goBack" content="详情页面">
    <!-- <el-descriptions 
        :colon="true"
        style="margin-top: 2%;">
        <el-descriptions-item label="资料名称">高三试题1</el-descriptions-item>
        <el-descriptions-item label="学科">化学</el-descriptions-item>
        <el-descriptions-item label="年级">高三(上)</el-descriptions-item>
        <el-descriptions-item label="文件地址">https://baidu.com/</el-descriptions-item>
    </el-descriptions> -->
    
    <div class="editor_area">
        <quill-editor 
            v-model:content="informationInfo.content"
            theme="bubble" 
            :read-only="true"
            >
        </quill-editor>
    </div>
</el-page-header>
</template>

<script>
import { QuillEditor,Delta } from '../../../assets/js/@vueup/vue-quill'
import BlotFormatter from 'quill-blot-formatter'
//import '../../../assets/css/@vueup/vue-quill/dist/vue-quill.snow.css';
import '../../../assets/css/@vueup/vue-quill/dist/vue-quill.bubble.css';
import {detailAPI} from '../../../util/api/information.js'


import { reactive, toRefs,ref,onMounted } from 'vue';
import { useRoute,useRouter } from 'vue-router';

export default {
    components: {
        QuillEditor
    },
    setup(){
        const data = reactive({
            informationInfo: {
                name: "期末考试",
                id: "",
                updateTime:"",
                content:ref(new Delta([])),
                length:""
            },
            changed:false,
            firstEntry:true
        })

        const route = useRoute();
        const router=useRouter()

        const goBack=()=> {
            console.log('go back');
            router.go(-1);
        }

        onMounted(() => {
            detailAPI({"id":route.params.id}).then(res=>{
                if(res.code == '000000'){
                    const jsonObject = JSON.parse(res.data.content);
                    data.informationInfo.content = new Delta(jsonObject.ops);
                }else{
                    console.log("加载资料信息失败")
                }
            })
        })

        return{
            ...toRefs(data),
            onMounted,
            goBack
        }
    }

    

}
</script>

<style >

body {
    overflow: hidden;
    height: 100%;
}

.editor_area{
    overflow: auto;
    height: 100%;
}

</style>