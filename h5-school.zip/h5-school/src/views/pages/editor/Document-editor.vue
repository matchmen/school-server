<template>
    <div>
      <div class="editor-container">
        <div id="editor-toolbar" ></div>
      <div id="editorjs"></div>
    </div>
    </div>


</template>

<script>

import EditorJS from '@editorjs/editorjs';
import Header from '@editorjs/header'; 
import List from '@editorjs/list'; 
import { ref, onMounted, onBeforeUnmount } from 'vue';

export default {
    setup() {
    const editorRef = ref(null);
    let editorInstance;

    onMounted(() => {
      editorInstance = new EditorJS({
        holder: 'editorjs',
        toolbar: 'editor-toolbar',
      });
      console.log(editorInstance)
    })

    onBeforeUnmount(() => {
      editorInstance && editorInstance.destroy();
    });

    return {
    };
  },
}
</script>

<style>
.editor-container {
  position: relative;
}

#editor-toolbar {
  position: sticky;
  top: 0;
  background-color: #f4f4f4;
  /* 其他样式属性 */
}
</style>