<template>
    <div class="editor_containor">
        <div class="editor_header" >
            <div class="header_left">
                <div style="margin-left: 10px;border: none;">
                <el-tooltip content="返回列表页" placement="bottom" effect="dark">
                    <el-button @click="back" style="border: none;"><el-icon :size="25"><HomeFilled /></el-icon></el-button>
                </el-tooltip>
                </div>
                <el-divider direction="vertical"></el-divider>
                <div>
                    <el-tooltip content="资料名称" placement="bottom" effect="dark">
                        <span class="span_class">{{ informationInfo.name }}</span>
                    </el-tooltip>
                </div>
                <el-divider direction="vertical"></el-divider>
                <div style="margin-top: 10px;">
                    <el-tooltip content="文档内容自动保存" placement="bottom" effect="dark">
                        <el-icon :size="18"><CircleCheck /></el-icon>
                    </el-tooltip>
                    <span style="max-width: calc(100% - 21px); margin-left: 5px;font-size:15px;line-height:18px;color:#ccc;">总字数{{ informationInfo.length }}，上次保存时间 {{ informationInfo.updateTime }}</span>
                </div>
            </div>
            <div class="header_right">
                <div style="margin-right: 10px;">
                <el-button color="#626aef" @click="saveContent"  :disabled="!changed" >保存</el-button>
                </div>
                <el-divider direction="vertical"></el-divider>
                <div style="margin-right: 10px;">
                    <el-button color="#626aef" >分享</el-button>
                </div>

            </div>
        </div>
        <div class="editor_area">
            <quill-editor 
                v-model:content="informationInfo.content"
                theme="snow" 
                :modules="modules"
                @text-change="textChangeHandle"
                >
            </quill-editor>
        </div>
    </div>
</template>

<script>
import { QuillEditor,Delta } from '../../../assets/js/@vueup/vue-quill'
import BlotFormatter from 'quill-blot-formatter'
import '../../../assets/css/@vueup/vue-quill/dist/vue-quill.snow.css';
//import '../../../assets/css/@vueup/vue-quill/dist/vue-quill.bubble.css';
import {detailAPI,updateContentAPI} from '../../../util/api/information.js'


import { reactive, toRefs,ref,onMounted } from 'vue';
import { useRoute,useRouter } from 'vue-router';

export default {
    components: {
        QuillEditor
    },
    setup(){
        const data = reactive({
            informationInfo: {
                name: "期末考试",
                id: "",
                updateTime:"",
                content:ref(new Delta([])),
                length:""
            },
            changed:false,
            firstEntry:true
        })

        const route = useRoute();
        const router = useRouter();
        const modules = {
            name: 'blotFormatter',
            module: BlotFormatter,
            options: {
            }
        }

        onMounted(() => {
            detailAPI({"id":route.params.id}).then(res=>{
                if(res.code == '000000'){
                    data.informationInfo.id = res.data.id
                    data.informationInfo.name = res.data.informationName
                    data.informationInfo.updateTime = res.data.updateTime
                    if(null != res.data.content){
                        const jsonObject = JSON.parse(res.data.content);
                        data.informationInfo.content = new Delta(jsonObject.ops);
                    }
                    data.changed = false;
                    
                }else{
                    console.log("加载资料信息失败")
                }
            })
        })

        const back =()=>{
            router.push({
                path: "/information"
            })
        }

        const saveContent =()=>{
            updateContentAPI({
                id:data.informationInfo.id,
                content: JSON.stringify(data.informationInfo.content)
            }).then(res=>{
                if(res.code == '000000'){
                    data.informationInfo.updateTime=res.data.updateTime
                    data.changed = false
                }else{
                    console.log("自动保存失败")
                }
            })
        }

        const textChangeHandle=()=>{
            data.changed = !data.firstEntry && true;
            data.firstEntry = false;
        }
        return{
            ...toRefs(data),
            modules,
            onMounted,
            textChangeHandle,
            saveContent,
            back
        }
    }
}
</script>

<style >

body {
  overflow: hidden;
  height: 100%;
}

.editor_containor{
    width: 100%;
    height: 100%;
}

.editor_header{
    width: 100%;
    margin-top: 5px;
    height: 40px;
    border-bottom: 1px solid #ccc;
    display: flex;
    align-items: center;
}

.editor_area{
    width: 100%;
}
    
.header_left {
    align-items: center;
    display: flex;
    width: 95%;
}

.header_right {
    margin-right: 10px;
    align-items: center;
    display: flex;
}

.span_class{
    max-width: 1em;
    font-size:18px;
    font-weight:500;
    color: black;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis; 
}



</style>