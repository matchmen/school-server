<template>
    <div>
      <div ref="editorContainer"></div>
    </div>
  </template>
  
  <script>
  import { onMounted, ref } from 'vue';
  import Quill from 'quill';
  //import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.bubble.css';
  //import 'quill/dist/quill.snow.css';
  import '../../../assets/css/@vueup/vue-quill/dist/vue-quill.snow.css'
  export default {
    setup() {
      const editorContainer = ref(null);
      let quill = null;
  
      onMounted(() => {
        quill = new Quill(editorContainer.value, {
          theme: 'snow', // 使用气泡样式
          placeholder: '输入内容...', // 输入框的占位符文本
        });
  
        // 设置初始内容
        const initialContent = '<p>Hello, Quill!</p>';
        quill.clipboard.dangerouslyPasteHTML(initialContent);
      });
  
      return {
        editorContainer,
      };
    },
  };
  </script>