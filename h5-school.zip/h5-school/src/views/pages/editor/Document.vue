<template>
<div class="first_contailer">  <!-- 最外层容器 -->
    <div class="second_container menu_container" >  <!-- 菜单栏容器(主要摆放历史记录按钮，分享，标题等元素) -->
        <div class="menu_left">
            <div style="margin-left: 10px;border: none;">
                <el-tooltip content="返回列表页" placement="bottom" effect="dark">
                    <el-button style="border: none;"><el-icon :size="25"><HomeFilled /></el-icon></el-button>
                </el-tooltip>
            </div>
            <el-divider direction="vertical"></el-divider>
            <div>
                <el-tooltip content="资料名称" placement="bottom" effect="dark">
                    <span class="span_class">{{ informationInfo.name }}</span>
                </el-tooltip>
            </div>
            <el-divider direction="vertical"></el-divider>
            <div style="margin-top: 10px;">
                <el-tooltip content="文档内容自动保存" placement="bottom" effect="dark">
                    <el-icon :size="18"><CircleCheck /></el-icon>
                </el-tooltip>
                <span style="max-width: calc(100% - 21px); margin-left: 5px;font-size:15px;line-height:18px;color:#ccc;">总字数{{ informationInfo.length }}，上次保存时间 {{ informationInfo.updateTime }}</span>
            </div>
        </div>
        <div class="menu_right">

            <div style="margin-right: 10px;">
                <el-button color="#626aef" @click="saveContent"  :disabled="!changed" >保存</el-button>
            </div>
            <el-divider direction="vertical"></el-divider>
            <div style="margin-right: 10px;">
                <el-button color="#626aef" >分享</el-button>
            </div>
            <!-- <el-divider direction="vertical"></el-divider> -->
            <!-- <div style="margin-right: 10px;">
                <el-image style="width: 18px; height: 18px" :src="userContext.header" :fit="none" />
            </div> -->
        </div>
    </div>
    
    <div class="second_container tool_containor" >  <!-- 编辑器工具栏容器 -->
        <Toolbar
            style="border-bottom: 1px solid #ccc"
            :editor="editorRef"
            :defaultConfig="toolbarConfig"
            :mode="mode"
        />
    </div>
    <div class="second_container content_container" >  <!-- 内容容器（大纲，文档内容，编注等元素） -->
        <!-- <div class="content_container_left"></div> -->
        <div class="editor_contailer">
            <!-- <div id="title-container"><input placeholder="请输入标题"></div> -->
            <Editor
                @keydown.ctrl.stop="saveContent"
                @keydown.command.stop="saveContent"
                class="editor_class"
                :defaultConfig="editorConfig"
                :mode="mode"
                @onCreated="handleCreated"
                @onChange="handleChange"
            />
        </div>
    </div>

</div>
</template>

<script>
import '@wangeditor/editor/dist/css/style.css' 
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'
import { DomEditor } from '@wangeditor/editor'
import {detailAPI,updateContentAPI} from '../../../util/api/information.js'

import { useRoute } from 'vue-router';


import { onBeforeUnmount, shallowRef,onMounted ,onUnmounted,myKeydown} from 'vue'
import { reactive } from '@vue/reactivity'
import { toRefs } from '@vue/reactivity'

export default {
    components: { 
        Editor, 
        Toolbar,
        DomEditor
    },
    setup(){
        const editorRef = shallowRef()
        const userContext={
            header:""
        }

        const data = reactive({
            informationInfo: {
                name: "",
                id: "",
                updateTime:"",
                content:"",
                length:""
            },
            changed:false
        })

        // 定义定时器
        let timer;

        // 定义定时器逻辑
        const startTimer = () => {
            timer = setTimeout(() => {
                if(!data.changed) return;
                //saveContent();
            }, 1* 60 * 1000);
        };

        const route = useRoute();

        // 组件销毁时，也及时销毁编辑器
        onBeforeUnmount(() => {
            const editor = editorRef.value
            if (editor == null) return
            editor.destroy()
        })
        const toolbarConfig = {
            excludeKeys:["fullScreen"]
        }
        const editorConfig = {
           // autoFocus:false,
            scroll:false,
            placeholder:"请输入..."
        }
        const handleCreated = (editor) => {
            editorRef.value = editor // 记录 editor 实例，重要！
            detailAPI({"id":route.params.id}).then(res=>{
                if(res.code == '000000'){
                    data.informationInfo.id = res.data.id
                    data.informationInfo.name = res.data.informationName
                    data.informationInfo.updateTime = res.data.updateTime
                    data.informationInfo.content = res.data.content
                    if(null != res.data.content && res.data.content != ''){
                        editor.setHtml(res.data.content)
                        data.informationInfo.length = editor.getText().length;
                    }
                }else{
                    console.log("加载资料信息失败")
                }
            })
        }

        const handleChange = (editor)=>{

            if(editor.getHtml() != data.informationInfo.content){
                data.changed = true;
                let text = editor.getText();
                data.informationInfo.length = text.length;

            }else{
                data.changed = false;
            }

            //console.log("xxx:"+data.changed)
            //console.log(editor.getConfig())
            //const toolbar = DomEditor.getToolbar(editor)
            //console.log(toolbar.getConfig())
            //console.log("html:"+editor.getHtml())
            //console.log("text:"+editor.getText())
        }

        const saveContent =()=>{
            console.log("鼠标事件")
            const editor = editorRef.value
            updateContentAPI({
                id:data.informationInfo.id,
                content: editor.getHtml()
            }).then(res=>{
                if(res.code == '000000'){
                    data.informationInfo.updateTime=res.data.updateTime
                    data.changed = false
                    data.informationInfo.content = editor.getHtml()
                }else{
                    console.log("自动保存失败")
                }
            })
        }

        const myKeydown = ()=>{
            console.log("xxxxxx")
        }

        onMounted(() => {
            startTimer()
        })

        onUnmounted(() => {
            clearTimeout(timer);
        });


        return {
            ...toRefs(data),
            editorRef,
            mode: 'default', // 或 'simple'
            toolbarConfig,
            editorConfig,
            handleCreated,
            handleChange,
            userContext,
            saveContent,
            myKeydown
        }
    }

}
</script>

<style>
body {
  overflow: hidden;
  height: 100%;
}
div#app {
  text-align: initial;
  overflow: hidden;
}
.first_contailer{
    width: 100%;
    height: 100%;
}

.menu_left {
    align-items: center;
    display: flex;
    width: 95%;
}

.menu_right {
    margin-right: 10px;
    align-items: center;
    display: flex;
}

.span_class{
    max-width: 1em;
    font-size:18px;
    font-weight:500;
    color: black;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis; 
}

/* .second_container{
    width: 100%;
} */
.menu_container{
    margin-top: 5px;
    height: 50px;
    border-bottom: 1px solid #ccc;
    display: flex;
    align-items: center;
}

.tool_containor{
    height: 40px;
    border-bottom: 1px solid #ccc;
}
.content_container{
    margin-top: 0px;
    background-color: #f3f5f7;
    /* height: 1000px; */
    height: 90vh;
    min-height: 350px;
    /* min-height: 1000px; */
    overflow-y: auto;
    position: relative;

}
.content_container_left{
    width: 350px
}

.editor_contailer{
    height: calc(100% -30px);
    /* height: 700px; */
    width: 850px;
    margin: 30px auto 150px auto;
    background-color: #fff;
    padding: 20px 50px 50px 50px;
    border: 1px solid #e8e8e8;
    box-shadow: 0 2px 10px rgb(0 0 0 / 12%);
}


.editor_class{
    min-height: 900px;
    width: 793.667px;
    overflow: hidden;
    /* margin-top: 10px;
    width: 793.667px;
    margin-top: 10px; */
    /* box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.2); */
}

#title-container {
    padding: 20px 0;
    border-bottom: 1px solid #e8e8e8;
}

#title-container input {
    font-size: 25px;
    border: 0;
    outline: none;
    width: 100%;
    line-height: 1;
}
</style>../../../util/api/information.js