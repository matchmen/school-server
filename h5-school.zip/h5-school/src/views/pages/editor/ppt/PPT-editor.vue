<template>
    <div>
      <!-- <pptist>
        <pptist-slide>
          <h1>Welcome to Pptist!</h1>
          <p>This is a demo slide.</p>
        </pptist-slide>
        
        <pptist-slide>
          <h2>Slide 2</h2>
          <p>This is another slide.</p>
        </pptist-slide>
        
        <pptist-slide>
          <h3>Slide 3</h3>
          <p>Yet another slide.</p>
        </pptist-slide>
      </pptist> -->
    </div>
  </template>
  
  <script>
  //import { Pptist, PptistSlide } from 'pptist';
  
  export default {
    // components: {
    //   Pptist,
    //   PptistSlide
    // }
  }
  </script>