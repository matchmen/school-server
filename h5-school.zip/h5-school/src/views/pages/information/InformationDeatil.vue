<template>
    <div>
        <el-page-header @back="goBack" content="详情页面">
        <el-descriptions 
            :colon="true"
            style="margin-top: 5%;">
            <el-descriptions-item label="资料名称">高三试题1</el-descriptions-item>
            <el-descriptions-item label="学科">化学</el-descriptions-item>
            <el-descriptions-item label="年级">高三(上)</el-descriptions-item>
            <el-descriptions-item label="文件地址">https://baidu.com/</el-descriptions-item>
        </el-descriptions>
    </el-page-header>
    </div>
</template>
<script>
import { reactive, toRefs,computed } from 'vue'
import { useRouter } from 'vue-router';
export default {
    setup(){
        const router=useRouter()
        const data = reactive({

        })

        const goBack=()=> {
            console.log('go back');
            router.go(-1);
        }

        return{
            ...toRefs(data),
            goBack
        }

    }

}
</script>

<style>

</style>