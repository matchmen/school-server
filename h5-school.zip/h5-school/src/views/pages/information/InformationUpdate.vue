<template>
  <div>
      <el-form 
        ref="informationUpdateRef" 
        class="rinformation-from"
        :model="informationData">
        <el-form-item 
          prop="informationName"
          label="名称"
          :rules="[{
                    required:true,
                    message:'请输入资料名称',
                    trigger: 'blur',
                 }]">
          <el-input placeholder="请输入资料名称"  v-model="informationData.informationName">
          </el-input>
        </el-form-item>

        <el-form-item 
          prop="subjectId"
          label="学科"
          :rules="[{
                    required:true,
                    message:'请选择学科',
                    trigger: 'blur',
                 }]">

          <el-select v-model="informationData.subjectId" placeholder="请选择学科">
            <el-option v-for="option in subjectDropdownList" :key="option.key" :label="option.desc" :value="option.key" />
          </el-select>
        </el-form-item>
        
        <el-form-item 
          prop="gradeId"
          label="年级"
          :rules="[{
                    required:true,
                    message:'请选择年级',
                    trigger: 'blur',
                 }]">
          <el-select v-model="informationData.gradeId" placeholder="请选择年级">
            <el-option v-for="option in gradeDropdownList" :key="option.key" :label="option.desc" :value="option.key" />
          </el-select>
        </el-form-item>

        <el-form-item 
          prop="volume"
          label="上/下册"
          :rules="[{
                    required:true,
                    message:'上册/下册',
                    trigger: 'blur',
                 }]">
              <el-radio-group v-model="informationData.volume">
                <el-radio label="VOLUME_ONE" >上册</el-radio>
                <el-radio label="VOLUME_TWO" >下册</el-radio>
              </el-radio-group>
        </el-form-item>

        <el-form-item 
          prop="addMethod"
          label="新建/上传文档"
          :rules="[{
                    required:true,
                    message:'上册/下册',
                    trigger: 'blur',
                 }]">
              <el-radio-group v-model="informationData.addMethod">
                <el-radio label="NEW_DOC" >新建</el-radio>
                <el-radio label="UPLOAD_DOC" >上传</el-radio>
              </el-radio-group>
        </el-form-item>

        <el-form-item 
          prop="docType"
          v-show="informationData.addMethod == 'NEW_DOC'"
          label="文档类型"
          :rules="[{
                    message:'请选择文档类型',
                    trigger: 'blur',
                 }]">

          <el-select v-model="informationData.docType" placeholder="请选择文档类型">
            <el-option v-for="option in docTypeDropdownList" :key="option.key" :label="option.desc" :value="option.key" />
          </el-select>
        </el-form-item>


        <el-form-item 
          v-show="informationData.addMethod == 'UPLOAD_DOC'"
          prop="file"
          label="文件"
          >
            <el-upload
              class="upload-demo"
              :on-change="handleChange">
              <el-button size="small" type="primary">文件上传</el-button>
            </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancelAdd">取 消</el-button>
        <el-button type="primary" @click="confirmAdd">确 定</el-button>
      </div>
  </div>
</template>

<script>
import { reactive, toRefs,ref,onMounted } from 'vue'
import {gradeDropdownApi,subjectDropdownApi,docTypeDropdownApi} from '../../../util/api/common.js'
import {addAPI} from '../../../util/api/information.js'
import { useRouter } from 'vue-router'
export default {
  props: {
    cancelAdd: {
      type: Function,
      required: true,
    }
  },
  setup(props){
    const informationUpdateRef= ref(null)
    const router=useRouter()
    const data = reactive({
      informationData:{
        "informationName":"",
        "subjectId":"",
        "gradeId":"",
        "volume":"VOLUME_ONE",
        "docType":"WORD",
        "addMethod":"NEW_DOC"
      },
      gradeDropdownList: [],
      subjectDropdownList: [],
      docTypeDropdownList: []
    })
    const handleChange=()=>{

    }
    const confirmAdd=()=>{
      informationAddRef.value.validate((valid) => {
        if(valid){
          addAPI(data.informationData).then(res=>{
              if(res.code == '000000'){
                if(data.informationData.addMethod=='UPLOAD_DOC'){
                  props.cancelAdd()
                }else{
                  router.push({
                      path: "/doc/"+res.data.id

                  })
                }
              }
            })
          }
        })
    }

    onMounted(() => {
      gradeDropdownApi().then(res=>{
          if(res.code == '000000'){
            data.gradeDropdownList = res.data
          }else{
              console.log("加载年级信息失败")
          }
      })
      subjectDropdownApi().then(res=>{
          if(res.code == '000000'){
            data.subjectDropdownList = res.data
          }else{
              console.log("加载科目信息失败")
          }
      })
      docTypeDropdownApi().then(res=>{
          if(res.code == '000000'){
            data.docTypeDropdownList = res.data
          }else{
              console.log("加载文件类型信息失败")
          }
      })
  
    })
    
    return{
      ...toRefs(data),
      informationAddRef,
      handleChange,
      cancelAdd:props.cancelAdd,
      confirmAdd
    }
  }

}
</script>

<style>
.el-select{
  width: 100%;
}
.el-form-item{
  margin-top: 30px;
}

</style>../../../util/api/information.js