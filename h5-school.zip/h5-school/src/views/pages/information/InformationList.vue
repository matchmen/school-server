<template>
  <div>

    <el-breadcrumb separator-class="el-icon-arrow-right breadcrumb_class">
      <el-breadcrumb-item>我的资料</el-breadcrumb-item>
      <el-breadcrumb-item>资料列表</el-breadcrumb-item>
    </el-breadcrumb>

    <el-form :model="searchData" class="search-from" style="width: 100%"  >
      <el-form-item label="资料名称" prop="informationName">
        <el-input placeholder="请输入资料名称"  v-model="searchData.informationName"></el-input>
      </el-form-item>
      <el-form-item label="科目名称" prop="subjectId">
        <el-select v-model="searchData.subjectId" placeholder="请选择年级">
          <el-option v-for="option in subjectDropdownList" :key="option.key" :label="option.desc" :value="option.key" />
        </el-select>
      </el-form-item>
      <el-form-item label="年级" prop="gradeId">
        <el-select v-model="searchData.gradeId" placeholder="请选择年级">
          <el-option v-for="option in gradeDropdownList" :key="option.key" :label="option.desc" :value="option.key" />
        </el-select>
      </el-form-item>
      <el-form-item label="上下册" prop="volume">
        <el-select v-model="searchData.volume" placeholder="请选择上下册">
          <el-option label="上册" value="VOLUME_ONE"></el-option>
          <el-option label="下册" value="VOLUME_TWO"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button style="margin-left: 10px;" type="primary" @click="search">搜索</el-button>
        <el-button style="margin-right: 10px;" @click="showAddDialog = true">上传资料</el-button>
      </el-form-item>
    </el-form>

    <el-dialog
          title="填写资料信息"
          :modal="false"
          style="width: 35%;"
          :before-close="closeAddDialog"
          v-model="showAddDialog">
          <AddInfoComponent 
            :cancelAdd="closeAddDialog"
            >
          </AddInfoComponent>
    </el-dialog>

    <el-table
      :data="tableData"
      highlight-current-row
      :header-cell-style="{background: 'var(--el-fill-color-light)'}"
      style="width: 100%">
        <el-table-column
          type="selection"
          width="30px"
          label="序号">
        </el-table-column>
        <el-table-column
          prop="informationName"
          width="200px"
          align="center"
          label="资料名称">
        </el-table-column>
        <el-table-column
          prop="subjectName"
          width="100px"
          align="center"
          label="学科">
        </el-table-column>
        <el-table-column
          prop="grade"
          align="center"
          width="150px"
          label="年级">
        </el-table-column>
        <el-table-column
          prop="statusDesc"
          align="center"
          width="100px"
          label="状态">
        </el-table-column>
        <el-table-column
          prop="createTime"
          align="center"
          width="200px"
          label="上传时间">
        </el-table-column>
        <el-table-column
          label="操作">
          <template #default="scope">
            <el-button @click="checkDetail(scope.row)" >查看</el-button>
            <el-button @click="editInfo(scope.row)">编辑</el-button>
            <el-button >下载</el-button>
          </template>
        </el-table-column>
    </el-table>
    <el-dialog
              title="编辑资料信息"
              :modal="false"
              style="width: 35%;"
              :before-close="closeEditDialog"
              v-model="showEditDialog">

          </el-dialog>

    <el-pagination class="pagination_clazz"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageData.currencyPage"
      :page-sizes="[10, 20, 50,100]"
      :page-size="pageData.pageSize"
      :prev-text="'上一页'"
      :next-text="'下一页'"
      layout="total, sizes, prev, pager, next"
      :total="pageData.total">
    </el-pagination>
  </div>
</template>

<script>
import { reactive, toRefs ,onMounted} from 'vue';
import { useRouter } from 'vue-router';
import AddInfoComponent from './InformationAdd.vue';
import EditInfoComponent from './InformationUpdate.vue';
import {gradeDropdownApi,subjectDropdownApi} from '../../../util/api/common.js'
import {searchAPI} from '../../../util/api/information.js'

export default {
  components:{
    AddInfoComponent,
    EditInfoComponent
  },
  setup(){
    const router = useRouter()
    const data = reactive({ 
      tableData:[
        {
          "informationName": "",
          "informationStatus":"",
          "subjectName":"",
          "volume":"",
          "grade":"",
          "id":"",
          "statusDesc":"",
          "status":"",
          "createTime":""
        }
      ],
      searchData:{
        "informationName":"",
        "subjectId":"",
        "gradeId":"",
        "volume":"",
        "pageSize":"10",
        "currencyPage":"1"

      },
      pageData:{
        currencyPage:1,
        pageSize:10,
        total:0
      },
      showAddDialog:false,
      showEditDialog:false,
      gradeDropdownList: [],
      subjectDropdownList: [],
    })

    onMounted(() => {
      gradeDropdownApi().then(res=>{
          if(res.code == '000000'){
            data.gradeDropdownList = res.data
          }else{
              console.log("加载年级信息失败")
          }
      })
      subjectDropdownApi().then(res=>{
          if(res.code == '000000'){
            data.subjectDropdownList = res.data
          }else{
              console.log("加载科目信息失败")
          }
      })
      search()
      
    })

    const handleSizeChange =()=>{

    }

    const handleCurrentChange =()=>{
      
    }

    const checkDetail =(row)=>{
      router.push({
          path: "/doc-quill-browse/"+row.id
      })
    }

    const closeAddDialog =()=>{
        data.showAddDialog=false
    }

    const closeEditDialog =()=>{
        data.showEditDialog=false
    }

    const editInfo=(row)=>{
      router.push({
          path: "/doc-quill/"+row.id
      })
    }

    const search=()=>{
      searchAPI(data.searchData).then(res=>{
          if(res.code == '000000'){
              data.tableData=res.data.rows
              data.pageData.pageSize = res.data.pageSize
              data.pageData.total = res.data.total
          }else{
              console.log("no data")
          }
      })
    }

    return{
        ...toRefs(data),
        handleCurrentChange,
        handleSizeChange,
        checkDetail,
        closeAddDialog,
        closeEditDialog,
        editInfo,
        search
    }
  }
}
</script>

<style>
.search-from {
    margin-top: 2%;
    width: 100%;
    display: flex;
    justify-content: left;
    align-items: center; 
}

.pagination_clazz	{
  margin-top: 1%;
}

</style>../../../util/api/information.js