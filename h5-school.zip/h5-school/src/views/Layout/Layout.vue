<template>

  <div class="common-layout">
    <el-container>
      <el-header class="common-header flex-flaot">
        <div class="flex">
          <img src="../../assets/logo.png" class="logo" alt="">
          <h1 class="title">资料库</h1>
        </div>
        <div class="toolbar">
          <el-dropdown>
            <el-icon style="margin-right: 8px; margin-top: 4px"
              ><setting
            /></el-icon>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="logoutHandle" style="color=#777">退出</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
          <span>{{ loginData.username }}</span>
        </div>
      </el-header>
      <el-container>
        <el-aside class="common-aside" width="200px">
          <el-menu backgroud-color="none" text-color="#337ab7" :router="true">
            <el-menu-item index="/index">
              <template #title>
                <el-icon><Menu /></el-icon>
                <span>主页</span>
                </template>
            </el-menu-item>
            <el-sub-menu index ="2">
                <template #title>
                  <el-icon class="menu-icon"><Files /></el-icon>
                  <span>我的资料</span>
                </template>
                <el-menu-item-group>
                  <el-menu-item index="/information">资料列表</el-menu-item>
                </el-menu-item-group>
            </el-sub-menu>
            <el-sub-menu index ="3">
                <template #title>
                  <el-icon><User /></el-icon>
                  <span>我的信息</span>
                </template>
                <el-menu-item-group>
                  <el-menu-item index="/user">详情</el-menu-item>
                  <!-- <el-menu-item index="/user/update">修改</el-menu-item> 
                  <el-menu-item index="/user/updatePW">修改密码</el-menu-item>-->
                </el-menu-item-group>
            </el-sub-menu>
          </el-menu>
          

            <!-- <router-link to="index">首页</router-link>
            <router-link to="information">我的资料库</router-link>
            <router-link to="user">个人信息</router-link> -->
        </el-aside>
        <el-main>
            <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import { useStore } from 'vuex' 
import { useRouter } from 'vue-router'
import { userData } from "../../store/index.js"
import { reactive, toRefs,ref } from 'vue';


export default {

  setup(){
    const store = useStore()
    const router = useRouter()
    const data = reactive({
        loginData:{
            username:store.state.userContext.username
        }
    })
    const logoutHandle=()=>{
        localStorage.removeItem("userContext")
        router.push({
            path: "/login"
        })
    }
    return{
      ...toRefs(data),
      logoutHandle
        
    }
  }

}
</script>

<style>
    .el-container{
        height: 100vh;
        overflow: hidden;
    }
    .common-header{
        background-color: #f8f8f8;
        display: flex;
    }
    .common-aside{
      background-color: #f8f8f8
    }
    .logo{
      width: 80px;
    }
    .title{
      color:#777;
    }
    #span{
      font-weight:900;
    }

</style>