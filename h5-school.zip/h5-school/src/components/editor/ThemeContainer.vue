<template>
  
  <div 
    :class="['theme-div',{'move-cursor':opertion.draggable.value}]"
    :style="{
        top: position.offsetY + 'px',
        left: position.offsetX + 'px',
        width: size.width + 'px',
        height: size.height + 'px',
        cursor: cursorStyle
    }"
    @mouseenter="mouseenter"
    @mouseleave="mouseleave"
  >
        <h6>top: {{position.offsetY}} + 'px',</h6>
        <h6>left: {{position.offsetX}} + 'px',</h6>
        <h6>width: {{size.width}} + 'px',</h6>
        <h6>height: {{size.height}} + 'px'</h6>
        <h6>draggable: {{opertion.draggable.value}} </h6>
        <h6>isDragging: {{state.isDragging}} </h6>
        <h6>resizable: {{opertion.resizable.value}} </h6>
        <h6>isresizing: {{state.isresizing}} </h6>
  </div>

</template>

<script>
import { toRefs, reactive } from 'vue'
export default {

    setup(){
        const data=reactive({
            opertion: {
                draggable: {
                    type: Boolean,
                    value: false,
                },
                resizable: {
                    type: Boolean,
                    value: false,
                },
                editable: {
                    type: Boolean,
                    value: false
                }
            },
            position: {//元素位置以及活动范围
                parentContainerMinOffsetX:100,
                parentContainerMaxOffsetX:1500,
                parentContainerMinOffsetY:100,
                parentContainerMaxOffsetY:800,
                offsetX: 100,
                offsetY: 100
            },
            size: {
                width: 200,
                height: 350
            },
            state:{
                isDragging:false,
                isresizing:false
            },
            styleClass:{
                
            },
            cursorStyle: 'default',
            chird:[]
        })

        //鼠标进入事件（注册eventTrigger事件）
        const mouseenter=()=>{
            // 定义鼠标移动事件
            document.addEventListener('mousemove', eventTrigger)
        }

        //鼠标离开事件（删除eventTrigger事件）
        const mouseleave=()=>{
            // 定义鼠标移动事件
            document.removeEventListener('mousemove', eventTrigger)
        }

        const showResizeIcon=()=>{

        }
        
        //事件触发器
        const eventTrigger=(onMousemoveEnent)=>{
            //鼠标按下时候鼠标的位置
            let downX = onMousemoveEnent.clientX
            let downY = onMousemoveEnent.clientY
            //鼠标移动前元素位置20*20范围内
            const elementStartX = data.position.offsetX
            const elementStartY = data.position.offsetY

            //边缘定义 TODO 是否按百分比

            //鼠标是否在左上角(鼠标进入触发移动事件)
            if ((downX >= elementStartX+5 && downX <= elementStartX + 20) && (downY >= elementStartY+5 && downY <= elementStartY + 20)) { // 鼠标在左上角区域内
                data.opertion.draggable.value = !data.opertion.resizable.value && true;
                data.cursorStyle = 'move'
                document.addEventListener('mousedown', startDrag)
                return;
            }else{
                data.opertion.draggable.value = false
            }
            document.addEventListener('mousedown', startDrag)
            
            let elementEndX = data.position.offsetX + data.size.width
            let elementEndY = data.position.offsetY + data.size.height

            //上边框
            if((downX >=elementStartX+20 && downX <=elementEndX-20) && (downY >=elementStartY && downY <=elementStartY+5)){
                data.cursorStyle = 'ns-resize'
                document.addEventListener('mousedown', startTopResize)
                data.opertion.resizable.value = !data.opertion.draggable.value && true
                return;
            }else if((downX >=elementStartX+20 && downX <=elementEndX-20) && (downY <=elementEndY && downY >=elementEndY-5)){//下边框
                data.cursorStyle = 'ns-resize'
                document.addEventListener('mousedown', startBottomResize)
                data.opertion.resizable.value = !data.opertion.draggable.value && true
                return;
            }else if((downY >=elementStartY + 20 && downY <=elementEndY - 20) && (downX >=elementStartX && downX <=elementStartX+5)){//左边框
                data.cursorStyle = 'ew-resize'
                console.log("xxxxxxx")
                document.addEventListener('mousedown', startLeftResize)
                data.opertion.resizable.value = !data.opertion.draggable.value && true
                return;
            }else if((downY >= elementStartY + 20 && downY <=elementEndY-20) && (downX >=elementEndX - 5 && downX <=elementEndX)){//右边框
                data.cursorStyle = 'ew-resize'
                document.addEventListener('mousedown', startRightesize)
                data.opertion.resizable.value = !data.opertion.draggable.value && true
                return;
            }
            document.removeEventListener('mousedown', startTopResize)
            document.removeEventListener('mousedown', startBottomResize)
            document.removeEventListener('mousedown', startLeftResize)
            document.removeEventListener('mousedown', startRightesize)
            data.cursorStyle = 'default'
            data.opertion.resizable.value = false
        

        }

        //右边框
        const startRightesize=(event)=>{
            //鼠标按下时候鼠标的位置
            let mouseDownX = event.clientX;
            //鼠标移动前元素位置X
            let downElementX = data.position.offsetX
            //鼠标移动前元素width
            let elementWidth = data.size.width
            //最大放大
            let rightMaxX = data.position.parentContainerMaxOffsetX - data.size.width - data.position.offsetX 
            //最大缩小
            let leftMinX = elementWidth - 10
            const resizing = (onMousemoveEnent) => {
                data.state.isresizing = true
                //鼠标移动的Y距离
                let moveX = onMousemoveEnent.clientX - mouseDownX
                //向左移动
                if(moveX < 0 ){
                    if(leftMinX >= Math.abs(moveX)){
                        data.size.width = elementWidth + moveX
                    }else{
                        data.size.width = elementWidth - leftMinX
                    }
                }else{//向右移动
                    if(moveX <= rightMaxX){
                        data.size.width = elementWidth + moveX
                    }else{
                        data.size.width = elementWidth + rightMaxX
                    }
                }

            }
            const stopResize=()=>{
                data.opertion.resizable.value = false
                data.state.isresizing = false
                document.removeEventListener('mousemove', resizing)
                document.removeEventListener('mouseup', stopResize)
            }

            if(data.opertion.resizable.value){
                document.removeEventListener('mousemove', eventTrigger)
                document.addEventListener('mousemove', resizing)
                document.addEventListener('mouseup', stopResize)
            }
        }

        //左边框
        const startLeftResize=(event)=>{
            //鼠标按下时候鼠标的位置
            let mouseDownX = event.clientX;
            //鼠标移动前元素位置X
            let downElementX = data.position.offsetX
            //鼠标移动前元素width
            let elementWidth = data.size.width
            //最大放大
            let leftMinX = downElementX - data.position.parentContainerMinOffsetX 
            //最小缩小
            let rightMaxX = elementWidth - 10
            const resizing = (onMousemoveEnent) => {
                data.state.isresizing = true
                //鼠标移动的Y距离
                let moveX = onMousemoveEnent.clientX - mouseDownX
                //向左移动
                if(moveX < 0 ){
                    if(leftMinX >= Math.abs(moveX)){
                        data.position.offsetX = downElementX + moveX 
                        data.size.width = elementWidth - moveX
                    }else{
                        data.position.offsetX = downElementX - leftMinX 
                        data.size.width = elementWidth - leftMinX
                    }
                }else{//向右移动
                    if(moveX <= rightMaxX){
                        data.position.offsetX = downElementX + moveX 
                        data.size.width = elementWidth - moveX
                    }else{
                        data.position.offsetX = downElementX + rightMaxX 
                        data.size.width = elementWidth - rightMaxX
                    }
                }

            }
            const stopResize=()=>{
                data.opertion.resizable.value = false
                data.state.isresizing = false
                document.removeEventListener('mousemove', resizing)
                document.removeEventListener('mouseup', stopResize)
            }

            if(data.opertion.resizable.value){
                document.removeEventListener('mousemove', eventTrigger)
                document.addEventListener('mousemove', resizing)
                document.addEventListener('mouseup', stopResize)
            }
        }

        //下边框
        const startBottomResize=(event)=>{
            //鼠标按下时候鼠标的位置
            let mouseDownY = event.clientY;
            //鼠标移动前元素位置Y
            let downElementY = data.position.offsetY
            //鼠标移动前元素heigt
            let elementHight = data.size.height
            //最小缩小
            let upMinY = data.size.height - 10
            //最大放大
            let downMaxY = data.position.parentContainerMaxOffsetY - downElementY - data.size.height
            const resizing = (onMousemoveEnent) => {
                data.state.isresizing = true
                //鼠标移动的Y距离
                let moveY = onMousemoveEnent.clientY - mouseDownY
                //向上移动
                if(moveY < 0 ){
                    if(upMinY >= Math.abs(moveY)){
                        data.size.height = elementHight + moveY
                    }else{
                        data.size.height = elementHight - upMinY
                    }
                }else{//向下移动
                    if(moveY <= downMaxY){
                        data.size.height = elementHight + Math.abs(moveY)
                    }else{
                        data.size.height = elementHight + downMaxY
                    }
                }

            }
            const stopResize=()=>{
                data.opertion.resizable.value = false
                data.state.isresizing = false
                document.removeEventListener('mousemove', resizing)
                document.removeEventListener('mouseup', stopResize)
            }

            if(data.opertion.resizable.value){
                document.removeEventListener('mousemove', eventTrigger)
                document.addEventListener('mousemove', resizing)
                document.addEventListener('mouseup', stopResize)
            }
        }

        

        //上边框
        const startTopResize=(event)=>{
            //鼠标按下时候鼠标的位置
            let mouseDownY = event.clientY;
            //鼠标移动前元素位置Y
            let downElementY = data.position.offsetY
            //鼠标移动前元素heigt
            let elementHight = data.size.height
            //最大放大
            let upMinY = downElementY - data.position.parentContainerMinOffsetY 
            //最小缩小
            let downMaxY = data.size.height - 10
            const resizing = (onMousemoveEnent) => {
                data.state.isresizing = true
                //鼠标移动的Y距离
                let moveY = onMousemoveEnent.clientY - mouseDownY
                //向上移动
                if(moveY < 0 ){
                    if(upMinY >= Math.abs(moveY)){
                        data.position.offsetY = downElementY + moveY
                        data.size.height = elementHight +  Math.abs(moveY)
                    }else{
                        data.position.offsetY = data.position.parentContainerMinOffsetY
                        data.size.height = elementHight + upMinY
                    }
                }else{//向下移动
                    if(moveY <= downMaxY){
                        data.position.offsetY = downElementY + moveY 
                        data.size.height = elementHight - Math.abs(moveY)
                    }else{
                        data.position.offsetY = downElementY + downMaxY
                        data.size.height = elementHight - downMaxY
                    }
                }

            }
            const stopResize=()=>{
                data.opertion.resizable.value = false
                data.state.isresizing = false
                document.removeEventListener('mousemove', resizing)
                document.removeEventListener('mouseup', stopResize)
            }

            if(data.opertion.resizable.value){
                document.removeEventListener('mousemove', eventTrigger)
                document.addEventListener('mousemove', resizing)
                document.addEventListener('mouseup', stopResize)
            }
        }

        
        
        // 按下鼠标开始移动事件
        const startDrag =(event)=>{

            //鼠标按下时候鼠标的位置
            let downX = event.clientX;
            let downY = event.clientY;

            //鼠标移动前元素位置
            const downElementX = data.position.offsetX
            const downElementY = data.position.offsetY

            // 定义鼠标移动事件
            const dragging = (onMousemoveEnent) => {
                data.state.isDragging = true;

                //元素最大最小坐标范围
                let elementMinX = data.position.parentContainerMinOffsetX;
                let elementMaxX = data.position.parentContainerMaxOffsetX - data.size.width;
                let elementMinY = data.position.parentContainerMinOffsetY;
                let elementMaxY = data.position.parentContainerMaxOffsetY - data.size.height;

                //鼠标移动的距离
                let moveX = onMousemoveEnent.clientX - downX
                let moveY = onMousemoveEnent.clientY - downY
                //鼠标移动距离 + 元素原来位置 = 现在元素位置
                let elementX = downElementX + moveX
                let elementY = downElementY + moveY
                //是否在X坐标范围内
                if(elementX >= elementMinX && elementX <= elementMaxX){
                    elementX = elementX
                }else if(elementX > data.position.parentContainerMaxOffsetX-data.size.width){
                    elementX = elementMaxX
                }else{
                    elementX = elementMinX
                }
                data.position.offsetX = elementX
                //是否在Y坐标范围内
                if(elementY >= elementMinY && elementY <= elementMaxY){
                    elementY = elementY
                }else if(elementY < elementMinY){
                    elementY = elementMinY
                }else{
                    elementY = elementMaxY
                }
                data.position.offsetY = elementY
            }
            // 定义鼠标移动事件
            const stopDrag = () => {
                data.state.isDragging = false
                data.opertion.draggable.value = false;
                // 移除document事件
                document.removeEventListener('mousemove', dragging)
                document.removeEventListener('mouseup', stopDrag)
                //document.addEventListener('mousemove', showDragFlg)
                document.removeEventListener('mousedown', startDrag)
                
            }
            if(data.opertion.draggable.value){
                //替换移动事件
                //document.removeEventListener('mousemove', showDragFlg)
                // 位document注册鼠标移动事件
                document.addEventListener('mousemove', dragging)
                // 鼠标抬起事件
                document.addEventListener('mouseup', stopDrag)
            }
        }

        return{
            ...toRefs(data),
            mouseenter,
            mouseleave
        }
    }
}
</script>

<style>
.theme-div{
  position: absolute;
  background-color: #f1f1f1;
  padding: 1px;
  border: 1px solid; 
  
}
.move-cursor{
    cursor: move;
}

.left-resize-cursor{
    cursor: w-resize;
}

.top-resize-cursor{
    cursor: n-resize;
}

.right-resize-cursor{
    cursor: e-resize;
}

.bottom-resize-cursor{
    cursor: s-resize;
}
</style>