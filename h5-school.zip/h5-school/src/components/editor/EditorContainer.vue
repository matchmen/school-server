<template>
    <div>
        <Theme_Container>asdasd</Theme_Container>
    </div>
</template>

<script>
import {ThemeContainer} from './ThemeContainer.vue'
export default {

    components:{
        ThemeContainer
    }

}
</script>

<style>

</style>