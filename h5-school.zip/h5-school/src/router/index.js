import { createRouter, createWebHashHistory,createWebHistory } from 'vue-router'
import store from "../store/index.js"

const routes = [
  {
    path:'/ppt-editor',
    name:'PPTEditor',
    component:()=>import("../views/pages/editor/ppt/PPT-editor.vue")
  },
  {
    path:'/doc-quill-browse/:id',
    name:'DocumentQuillBrowse',
    component:()=>import("../views/pages/editor/Decument-browse.vue")
  },
  {
    path:'/doc-quill/:id',
    name:'DocumentQuill',
    component:()=>import("../views/pages/editor/Document-quill.vue")
  },{
    path:'/doc-editor',
    name:'DocumentEditor',
    component:()=>import("../views/pages/editor/Document-editor.vue")
  },{
    path:'/doc/:id',
    name:'Document',
    component:()=>import("../views/pages/editor/Document.vue")
  },{
    path: "/wang-editor",
    name: "Container",
    component:()=>import("../views/pages/demo/wang-editor/WangEditor.vue")
  },{
    path: "/theme",
    name: "Theme",
    component:()=>import("../components/editor/ThemeContainer.vue")
  },{
    path: "/quillDemo",
    name: "QuillDemo",
    component:()=>import("../views/pages/demo/quill/Test.vue")
  },{
    path: "/test",
    name: "Test",
    component:()=>import("../views/pages/Test.vue")
  },
  {
    path: "/login",
    name: "Login",
    component:()=>import("../views/pages/Login.vue")
  },{
    path: "/register",
    name: "Register",
    component:()=>import("../views/pages/Register.vue")
  },{
    path:'/',
    name:'Layout',
    redirect:"/index",
    component:()=>import("../views/Layout/Layout.vue"),
    children:[
      {
        path:'/index',
        name:'Main',  
        component:()=>import("../views/pages/main/Home.vue"),
      },{
        path:'/information',
        name:'Information',
        component:()=>import("../views/pages/information/InformationList.vue")
      },{
        path:'/information/add',
        name:'InformationAdd',
        component:()=>import("../views/pages/information/InformationAdd.vue")
      },{
        path:'/information/update',
        name:'InformationUpdate',
        component:()=>import("../views/pages/information/InformationUpdate.vue")
      }
      ,{
        path:'/information/detail',
        name:'InformationDeatil',
        component:()=>import("../views/pages/information/InformationDeatil.vue")
      },{
        path:'/user',
        name:'UserInfo',
        component:()=>import("../views/pages/user/UserInfoDeatil.vue")
      },{
        path:'/user/update',
        name:'UpdateUser',
        component:()=>import("../views/pages/user/UpdateUserInfo.vue")
      },{
        path:'/user/updatePW',
        name:'UpdatePassword',
        component:()=>import("../views/pages/user/UpdatePassword.vue")
      }
      
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to,from,next)=>{
  /**
   * to:从哪个页面
   * from：到哪个页面
   * next: 执行next()页面才会进行跳转
   */
  //判断用户是否登陆
  if(!store.state.userContext.username){
    if(to.path == "/login" || to.path == "/register" 
      || to.path == "/test" 
      || to.path == "/wang-editor"
      || to.path == "/doc-editor"
      || to.path == "/doc-quill1"
      || to.path == "/ppt-editor"
      || to.path == "/quillDemo"
      ){
      next()
      return
    }
    next("/login")
  }else{
    next()
  }

})

export default router
