import {post,get} from "./service"

export const searchAPI=data=>{
    return post({
        url:"/information/search",
        data
    })
}

export const addAPI=data=>{
    return post({
        url:"/information/add",
        data
    })
}

export const updateContentAPI=data=>{
    return post({
        url:"/information/updateContent",
        data
    })
}

export const detailAPI=data=>{
    return post({
        url:"/information/detail",
        data
    })
}