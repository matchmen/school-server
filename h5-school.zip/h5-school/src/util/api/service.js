import axios from "axios";
import { ElLoading, ElMessage } from 'element-plus'
import router from '../../router/index.js';
import store from '../../store/index.js'

let loadingObj = null
//创建axios实例
const Service = axios.create({
    timeout:10000,
    baseURL:"http://127.0.0.1:8090/",
    headers:{
        "Content-Type": "application/json;charset=utf-8"
    }
})
//请求拦截
Service.interceptors.request.use(config=>{
    loadingObj = ElLoading.service({
        lock: true,
        text: 'Loading',
        background: 'rgba(0, 0, 0, 0.7)',
      })
      config.headers['Authorization'] = store.state.userContext.token
      return config;
})
//响应拦截-返回值统一处理
Service.interceptors.response.use(response=>{
    loadingObj.close()
    const resData = response.data
    if(resData.code != '000000'){
        ElMessage.warning(resData.message||"服务器异常")
        return resData
    }
    return resData
},error=>{
    loadingObj.close()
    console.log(error)
    if(error.response.status == 400){
        ElMessage({
            message:error.message,
            type: "error",
            duration:2000
        })
    }else if(error.response.status == 500){
        ElMessage({
            message:"服务异常，请联系客服.",
            type: "error",
            duration:2000
        })
    }else if(error.response.status == 401){
        ElMessage({
            message:"请重新登陆",
            type: "error",
            duration:2000
        })
        router.push('/login');
    }else if(error.response.status == 403){
        ElMessage({
            message:"无法访问未授权资源",
            type: "error",
            duration:2000
        })
    }else {
        ElMessage({
            message:"服务异常，请联系客服.",
            type: "error",
            duration:2000
        })
    }
    return {
        "code":"-1"
    }
})
// post请求
export const post=config=>{
    return Service({
        ...config,
        method:"post",
        data:config.data
    })
}
// get请求
export const get=config=>{
    return Service({
        ...config,
        method:"get",
        data:config.data
    })
}