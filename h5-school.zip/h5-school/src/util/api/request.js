import {post,get} from "./service.js"

export const loginApi=data=>{
    return post({
        url:"/login",
        data
    })
}

export const sendCodeApi=data=>{
    return post({
        url:"/user/sendCode",
        data
    })
}

export const verifyCodeApi=data=>{
    return post({
        url:"/user/register",
        data
    })
}

export const userDetailApi=data=>{
    return get({
        url:"/user/userDetail"
    })
}

export const resetPasswordApi=data=>{
    return post({
        url:"/user/resetPassword",
        data
    })
}