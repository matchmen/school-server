import {post,get} from "./service"


export const gradeDropdownApi=data=>{
    return get({
        url:"/common/gradeDropdown"
    })
}

export const subjectDropdownApi=data=>{
    return get({
        url:"/common/subjectDropdown"
    })
}

export const docTypeDropdownApi=data=>{
    return get({
        url:"/common/docTypeDropdown"
    })
}