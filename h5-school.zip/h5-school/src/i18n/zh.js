export default {
    toolbar: {
      bold: '加粗',
      italic: '斜体',
      underline: '下划线',
      Large:"常规"
      // 其他工具栏按钮的翻译
    },
    // 其他翻译文本
  };