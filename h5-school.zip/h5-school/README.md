# h5-school

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Lints and fixes files
```
yarn lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


### 引用组件
1.word编辑器，其他同品
wangEditor: https://www.wangeditor.com/  性能较差，已经停止更新，bug较多
vue-qill:https://vueup.github.io/vue-quill/  https://quilljs.com/docs/quickstart/
2.PPT编辑器（PPTist）
3.Excel